import sys
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import RandomUnderSampler

from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from scipy.optimize import minimize

sys.path.insert(0, "src")
from importlib import import_module
ablation_module = import_module("04_qubit_ablation")
build_circuit = ablation_module.build_circuit
prob_one = ablation_module.prob_one

FEATURES_CSV = "results/quantum_features.csv"
TEST_SIZE = 0.20
SEED = 42
N_QUBITS = 4
N_LAYERS = 2
N_PARAMS = N_QUBITS * N_LAYERS * 2
SHOTS = 150
MAXITER = 25
QNN_SUBSET_SIZE = 100

TECHNIQUES = ["Original (imbalanced)", "Random Oversampling", "SMOTE", "Random Undersampling"]
RESULTS_FILE = "results/balancing_experiments_results.json"


def build_noise_model():
    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.001, 1), ['rx', 'ry', 'rz'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.01, 2), ['cx'])
    return noise_model


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


def apply_technique(technique, X_train, y_train, seed):
    if technique == "Original (imbalanced)":
        return X_train, y_train
    elif technique == "Random Oversampling":
        return RandomOverSampler(random_state=seed).fit_resample(X_train, y_train)
    elif technique == "SMOTE":
        return SMOTE(random_state=seed, k_neighbors=5).fit_resample(X_train, y_train)
    elif technique == "Random Undersampling":
        return RandomUnderSampler(random_state=seed).fit_resample(X_train, y_train)
    else:
        raise ValueError("unknown technique")


def train_evaluate_qnn(X_pool, y_pool, X_test, y_test, sim, seed):
    rng = np.random.default_rng(seed)
    n = len(X_pool)
    subset_size = min(QNN_SUBSET_SIZE, n)
    selected = rng.choice(n, size=subset_size, replace=False)
    X_train, y_train = X_pool[selected], y_pool[selected]

    def cost(params):
        total = 0.0
        for i in range(len(X_train)):
            p1 = prob_one(sim, params, X_train[i], N_QUBITS, N_LAYERS, shots=SHOTS)
            total += (p1 - y_train[i]) ** 2
        return total / len(X_train)

    np.random.seed(seed)
    init = np.random.rand(N_PARAMS) * 2 * np.pi
    res = minimize(cost, init, method='COBYLA', options={'maxiter': MAXITER})

    preds = []
    for i in range(len(X_test)):
        p1 = prob_one(sim, res.x, X_test[i], N_QUBITS, N_LAYERS, shots=SHOTS)
        preds.append(1 if p1 >= 0.5 else 0)

    return compute_metrics(y_test, preds), len(X_train), int(y_train.sum())


def load_results():
    import os
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_results(all_results):
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    feature_cols = [f'angle_{i}' for i in range(N_QUBITS)]
    X = df[feature_cols].values
    y = df['label'].values

    idx_all = np.arange(len(df))
    idx_train, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)
    X_train_orig, y_train_orig = X[idx_train], y[idx_train]
    X_test, y_test = X[idx_test], y[idx_test]

    print(f" Original train set: {len(X_train_orig)} (positive={int(y_train_orig.sum())}, "
          f"{y_train_orig.mean()*100:.1f}%) | Test: {len(X_test)} (positive={int(y_test.sum())})\n")

    all_results = load_results()
    sim = AerSimulator(noise_model=build_noise_model())

    if len(sys.argv) > 1:
        target_techniques = [TECHNIQUES[int(sys.argv[1])]]
    else:
        target_techniques = TECHNIQUES

    for technique in target_techniques:
        print(f"\n{'='*60}\n TECHNIQUE: {technique}\n{'='*60}")
        X_bal, y_bal = apply_technique(technique, X_train_orig, y_train_orig, SEED)
        print(f" Pool after balancing: {len(X_bal)} (positive={int(y_bal.sum())}, {y_bal.mean()*100:.1f}%)")

        svm_model = SVC(kernel='rbf')
        svm_model.fit(X_bal, y_bal)
        svm_metric = compute_metrics(y_test, svm_model.predict(X_test))

        mlp_model = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=1000, random_state=42)
        mlp_model.fit(X_bal, y_bal)
        mlp_metric = compute_metrics(y_test, mlp_model.predict(X_test))

        print(f" SVM -> Acc={svm_metric['accuracy']*100:.1f}% F1={svm_metric['f1']:.3f} Recall={svm_metric['recall']:.3f}")
        print(f" MLP -> Acc={mlp_metric['accuracy']*100:.1f}% F1={mlp_metric['f1']:.3f} Recall={mlp_metric['recall']:.3f}")

        print(" Training QNN (100-sample subset from pool)...")
        qnn_metric, n_qnn_train, n_qnn_pos = train_evaluate_qnn(X_bal, y_bal, X_test, y_test, sim, SEED)
        print(f" QNN -> Acc={qnn_metric['accuracy']*100:.1f}% F1={qnn_metric['f1']:.3f} "
              f"Recall={qnn_metric['recall']:.3f} (train: {n_qnn_train} samples, {n_qnn_pos} positive)")

        all_results[technique] = {
            "pool_size": len(X_bal), "pool_positive_ratio": float(y_bal.mean()),
            "svm": svm_metric, "mlp": mlp_metric, "qnn": qnn_metric,
            "qnn_train_size": n_qnn_train, "qnn_train_positive": n_qnn_pos
        }
        save_results(all_results)

    if len(all_results) < len(TECHNIQUES):
        print(f"\n {len(all_results)}/{len(TECHNIQUES)} techniques completed. Run remaining ones (0-3).")
        sys.exit(0)

    rows = []
    for technique in TECHNIQUES:
        r = all_results[technique]
        for model_name in ["svm", "mlp", "qnn"]:
            m = r[model_name]
            rows.append({"Technique": technique, "Model": model_name.upper(),
                         "Accuracy": round(m["accuracy"]*100, 1), "Precision": round(m["precision"], 3),
                         "Recall": round(m["recall"], 3), "F1": round(m["f1"], 3)})
    df_summary = pd.DataFrame(rows)
    print("\n=== SUMMARY TABLE ===")
    print(df_summary.to_string(index=False))
    df_summary.to_csv("results/balancing_experiments_summary.csv", index=False)

    model_names = ["svm", "mlp", "qnn"]
    model_labels = ["SVM", "MLP", "QNN (4 qubits)"]
    colors = ['#4a90e2', '#50e3c2', '#b8e986']

    fig, ax = plt.subplots(figsize=(12, 6))
    x = np.arange(len(TECHNIQUES))
    width = 0.25
    for i, (model_name, label, color) in enumerate(zip(model_names, model_labels, colors)):
        values = [all_results[t][model_name]["f1"] for t in TECHNIQUES]
        bars = ax.bar(x + i*width, values, width, label=label, color=color)
        for bar, v in zip(bars, values):
            ax.text(bar.get_x()+bar.get_width()/2, v+0.01, f"{v:.2f}", ha='center', fontsize=8)

    ax.set_xlabel('Balancing Technique')
    ax.set_ylabel('F1 Score (positive class)')
    ax.set_title('Effect of Balancing Technique on F1 Score (SVM vs MLP vs QNN)')
    ax.set_xticks(x + width)
    ax.set_xticklabels(TECHNIQUES, rotation=10, ha='right')
    ax.legend()
    ax.grid(alpha=0.3, axis='y')
    plt.tight_layout()
    plt.savefig("figures/balancing_experiments_comparison.png", dpi=130)
    print("\n Saved figures/balancing_experiments_comparison.png")
