import json
import os
import sys
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from scipy.optimize import minimize

FEATURES_CSV = "results/quantum_features.csv"
SHOTS = 150
TEST_SIZE = 0.20
SEED = 42
MAXITER = 20
TRAIN_SUBSET_SIZE = 100

CONFIGS = [
    {"n_qubits": 2, "n_layers": 1, "mode": "pooling"},
    {"n_qubits": 4, "n_layers": 2, "mode": "truncate"},
    {"n_qubits": 6, "n_layers": 2, "mode": "truncate"},
    {"n_qubits": 8, "n_layers": 2, "mode": "truncate"},
]

RESULTS_FILE = "results/qubit_ablation_results.json"


def build_noise_model():
    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.001, 1), ['rx', 'ry', 'rz'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.01, 2), ['cx'])
    return noise_model


def extract_features(df, mode, n_qubits):
    all_angle_cols = [c for c in df.columns if c.startswith('angle_')]
    if mode == "truncate":
        selected = all_angle_cols[:n_qubits]
        return df[selected].values
    elif mode == "pooling":
        values = df[all_angle_cols].values
        n_parts = n_qubits
        part_len = values.shape[1] // n_parts
        pooled = np.zeros((values.shape[0], n_parts))
        for p in range(n_parts):
            part = values[:, p*part_len:(p+1)*part_len]
            sin_mean = np.sin(part).mean(axis=1)
            cos_mean = np.cos(part).mean(axis=1)
            pooled[:, p] = np.arctan2(sin_mean, cos_mean) % (2 * np.pi)
        return pooled
    else:
        raise ValueError("unknown mode")


def build_circuit(angles, params, n_qubits, n_layers):
    qc = QuantumCircuit(n_qubits, 1)
    for i in range(n_qubits):
        qc.rx(angles[i], i)
    qc.barrier()
    idx = 0
    for l in range(n_layers):
        for i in range(n_qubits):
            qc.ry(params[idx], i)
            qc.rz(params[idx + 1], i)
            idx += 2
        for i in range(n_qubits):
            qc.cx(i, (i + 1) % n_qubits)
        qc.barrier()
    qc.measure(n_qubits - 1, 0)
    return qc


def prob_one(sim, params, angles, n_qubits, n_layers, shots=SHOTS):
    qc = build_circuit(angles, params, n_qubits, n_layers)
    result = sim.run(qc, shots=shots).result()
    counts = result.get_counts(qc)
    return counts.get('1', 0) / shots


def run_one_config(df, idx_train, idx_test, y, config, sim):
    n_qubits, n_layers, mode = config["n_qubits"], config["n_layers"], config["mode"]
    n_params = n_qubits * n_layers * 2
    print(f"\n{'='*60}\n CONFIG: {n_qubits} qubits, {n_layers} layers, mode={mode} ({n_params} params)\n{'='*60}")

    X = extract_features(df, mode, n_qubits)
    X_train, X_test = X[idx_train], X[idx_test]
    y_train, y_test = y[idx_train], y[idx_test]

    loss_history = []

    def cost(params):
        total = 0.0
        for i in range(len(X_train)):
            p1 = prob_one(sim, params, X_train[i], n_qubits, n_layers)
            total += (p1 - y_train[i]) ** 2
        avg = total / len(X_train)
        loss_history.append(avg)
        return avg

    np.random.seed(SEED)
    init = np.random.rand(n_params) * 2 * np.pi

    t0 = time.time()
    res = minimize(cost, init, method='COBYLA', options={'maxiter': MAXITER})
    elapsed = time.time() - t0

    preds, probs = [], []
    for i in range(len(X_test)):
        p1 = prob_one(sim, res.x, X_test[i], n_qubits, n_layers)
        probs.append(p1)
        preds.append(1 if p1 >= 0.5 else 0)

    acc = accuracy_score(y_test, preds)
    prec = precision_score(y_test, preds, zero_division=0)
    rec = recall_score(y_test, preds, zero_division=0)
    f1 = f1_score(y_test, preds, zero_division=0)
    test_loss = float(np.mean((np.array(probs) - y_test) ** 2))

    print(f" Training time: {elapsed:.1f}s | Final train loss: {res.fun:.4f}")
    print(f" Test Accuracy: {acc*100:.2f}% | Precision: {prec:.3f} | Recall: {rec:.3f} | F1: {f1:.3f}")

    return {
        "n_qubits": n_qubits, "n_layers": n_layers, "mode": mode, "n_params": n_params,
        "training_time_s": round(elapsed, 1), "final_train_loss": float(res.fun),
        "test_accuracy": acc, "test_precision": prec, "test_recall": rec, "test_f1": f1,
        "test_loss": test_loss, "loss_history": loss_history
    }


def load_results():
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_result(new_result):
    results = load_results()
    results = [r for r in results if r["n_qubits"] != new_result["n_qubits"]]
    results.append(new_result)
    results.sort(key=lambda r: r["n_qubits"])
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    return results


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    y = df['label'].values

    idx_all = np.arange(len(df))
    idx_train_full, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)

    rng = np.random.default_rng(SEED)
    pos_train = idx_train_full[y[idx_train_full] == 1]
    neg_train = idx_train_full[y[idx_train_full] == 0]
    n_pos_target = min(len(pos_train), TRAIN_SUBSET_SIZE // 2)
    n_neg_target = TRAIN_SUBSET_SIZE - n_pos_target
    pos_selected = rng.choice(pos_train, size=n_pos_target, replace=False)
    neg_selected = rng.choice(neg_train, size=min(n_neg_target, len(neg_train)), replace=False)
    idx_train = np.concatenate([pos_selected, neg_selected])
    rng.shuffle(idx_train)

    print(f" Train (subsample): {len(idx_train)} (positive={int(y[idx_train].sum())}) | Test: {len(idx_test)} (positive={int(y[idx_test].sum())})")

    sim = AerSimulator(noise_model=build_noise_model())

    if len(sys.argv) > 1:
        target_qubits = int(sys.argv[1])
        config_list = [c for c in CONFIGS if c["n_qubits"] == target_qubits]
    else:
        config_list = CONFIGS

    for config in config_list:
        result = run_one_config(df, idx_train, idx_test, y, config, sim)
        results = save_result(result)
        print(f" -> Saved. Completed configs: {len(results)}/4")

    results = load_results()
    if len(results) < 4:
        print(f"\n {len(results)}/4 configs completed. Re-run with remaining qubit counts.")
        sys.exit(0)

    df_summary = pd.DataFrame([{k: v for k, v in r.items() if k != 'loss_history'} for r in results])
    print("\n=== SUMMARY TABLE ===")
    print(df_summary[["n_qubits", "n_layers", "n_params", "test_accuracy", "test_precision",
                       "test_recall", "test_f1", "training_time_s"]].to_string(index=False))
    df_summary.to_csv("results/qubit_ablation_summary.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    qubit_counts = [r["n_qubits"] for r in results]

    ax = axes[0]
    ax.plot(qubit_counts, [r["test_accuracy"]*100 for r in results], 'o-', color='#4a90e2', linewidth=2, markersize=8)
    ax.set_xlabel('Number of Qubits')
    ax.set_ylabel('Test Accuracy (%)')
    ax.set_title('Test Accuracy vs Qubit Count')
    ax.set_xticks(qubit_counts)
    ax.grid(alpha=0.3)

    ax2 = axes[1]
    ax2.plot(qubit_counts, [r["test_f1"] for r in results], 's-', label='F1', color='#e74c3c', linewidth=2, markersize=8)
    ax2.plot(qubit_counts, [r["test_recall"] for r in results], '^-', label='Recall', color='#f39c12', linewidth=2, markersize=8)
    ax2.set_xlabel('Number of Qubits')
    ax2.set_ylabel('Score')
    ax2.set_title('F1 / Recall vs Qubit Count')
    ax2.set_xticks(qubit_counts)
    ax2.legend()
    ax2.grid(alpha=0.3)

    plt.suptitle(f'QNN Qubit-Count Ablation (same train/test split, N_test={len(idx_test)})', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/qubit_ablation_comparison.png", dpi=130)
    print("\n Saved figures/qubit_ablation_comparison.png")

    plt.figure(figsize=(9, 5.5))
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986']
    for r, color in zip(results, colors):
        plt.plot(r["loss_history"], label=f'{r["n_qubits"]} qubits ({r["mode"]})', color=color, linewidth=1.8)
    plt.xlabel('COBYLA Iteration')
    plt.ylabel('Training Loss (MSE)')
    plt.title('Training Loss Curve by Qubit Count')
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("figures/qubit_ablation_loss_curves.png", dpi=130)
    print(" Saved figures/qubit_ablation_loss_curves.png")

    best_f1 = max(results, key=lambda r: r["test_f1"])
    print(f"\n Highest F1 config: {best_f1['n_qubits']} qubits (F1={best_f1['test_f1']:.3f})")
