import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import mannwhitneyu

WEIGHTS = {"QNN_P1": 0.5, "Stability_Score": 0.3, "Off_Target_Term": 0.2}


def cohens_d(a, b):
    a, b = np.array(a), np.array(b)
    pooled_std = np.sqrt(((len(a)-1)*a.std(ddof=1)**2 + (len(b)-1)*b.std(ddof=1)**2) / (len(a)+len(b)-2)) \
        if len(a) > 1 and len(b) > 1 else np.nan
    return (a.mean() - b.mean()) / pooled_std if pooled_std and pooled_std > 0 else np.nan


if __name__ == "__main__":
    df = pd.read_csv("results/retrospective_aso_validation.csv")
    df["Off_Target_Term"] = 1 - df["Off_Target_Risk"]

    active = df[df["Category"] == "active"]
    control = df[df["Category"] == "control"]

    print("=== RAW SCORES ===")
    print(df[["ASO", "Category", "QNN_P1", "Stability_Score", "Off_Target_Term", "Combined_Score", "Rank"]]
          .to_string(index=False))

    print(f"\n Active mean combined score: {active['Combined_Score'].mean():.4f}")
    print(f" Control mean combined score: {control['Combined_Score'].mean():.4f}")
    print(f" Gap (active - control): {active['Combined_Score'].mean() - control['Combined_Score'].mean():+.4f}"
          f"  (negative = inverted ranking, as observed)")

    print("\n=== PER-COMPONENT GROUP MEANS AND WEIGHTED CONTRIBUTION TO THE SCORE GAP ===")
    contributions = {}
    for component, weight in WEIGHTS.items():
        a_mean = active[component].mean()
        c_mean = control[component].mean()
        raw_gap = a_mean - c_mean
        weighted_contribution = weight * raw_gap
        contributions[component] = weighted_contribution
        d = cohens_d(active[component].values, control[component].values)
        print(f" {component:18s}: active_mean={a_mean:.3f}  control_mean={c_mean:.3f}  "
              f"raw_gap={raw_gap:+.3f}  weight={weight}  weighted_contribution={weighted_contribution:+.4f}  "
              f"Cohen's d={d:+.2f}")

    total_check = sum(contributions.values())
    print(f"\n Sum of weighted contributions: {total_check:+.4f} "
          f"(should equal the combined-score gap above, {active['Combined_Score'].mean() - control['Combined_Score'].mean():+.4f})")

    worst_component = min(contributions, key=contributions.get)
    print(f"\n Component most responsible for the inverted ranking: {worst_component} "
          f"(contribution={contributions[worst_component]:+.4f})")

    print("\n=== ROBUSTNESS CHECK: excluding the 8-mer (extreme off-target outlier) ===")
    active_no8mer = active[~active["ASO"].str.contains("8-mer")]
    contributions_no8mer = {}
    for component, weight in WEIGHTS.items():
        a_mean = active_no8mer[component].mean()
        c_mean = control[component].mean()
        raw_gap = a_mean - c_mean
        weighted_contribution = weight * raw_gap
        contributions_no8mer[component] = weighted_contribution
        print(f" {component:18s}: active_mean(no 8-mer)={a_mean:.3f}  control_mean={c_mean:.3f}  "
              f"weighted_contribution={weighted_contribution:+.4f}")
    gap_no8mer = sum(contributions_no8mer.values())
    print(f" Combined-score gap without the 8-mer outlier: {gap_no8mer:+.4f} "
          f"({'still inverted' if gap_no8mer < 0 else 'corrected'})")
    worst_no8mer = min(contributions_no8mer, key=contributions_no8mer.get)
    print(f" Largest remaining driver: {worst_no8mer}")

    print("\n=== INDIVIDUAL-COMPONENT RANKING CHECK ===")
    print(" (If we ranked by ONE component alone, would actives beat controls?)")
    for component in ["QNN_P1", "Stability_Score", "Off_Target_Term"]:
        ranked = df.sort_values(component, ascending=False).reset_index(drop=True)
        ranked["solo_rank"] = ranked.index + 1
        a_rank = ranked[ranked["Category"] == "active"]["solo_rank"].mean()
        c_rank = ranked[ranked["Category"] == "control"]["solo_rank"].mean()
        verdict = "CORRECT direction (active ranks better)" if a_rank < c_rank else "INVERTED (control ranks better)"
        print(f" {component:18s}: active mean rank={a_rank:.2f}, control mean rank={c_rank:.2f} -> {verdict}")

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    components_plot = ["QNN_P1", "Stability_Score", "Off_Target_Term"]
    titles = ["QNN Output P(1)", "Thermodynamic Stability Score", "Off-Target Term (1 - risk)"]
    for ax, component, title in zip(axes, components_plot, titles):
        for category, color, offset in [("active", "#2ecc71", -0.15), ("control", "#e74c3c", 0.15)]:
            values = df[df["Category"] == category][component].values
            x = np.full(len(values), 0) + offset + np.random.default_rng(1).normal(0, 0.02, len(values))
            ax.scatter(x, values, color=color, s=90, label=category, zorder=3, edgecolor='black')
            ax.hlines(values.mean(), offset-0.08, offset+0.08, color=color, linewidth=2.5, zorder=4)
        ax.set_xticks([])
        ax.set_ylabel(title)
        ax.set_title(title)
        ax.grid(alpha=0.3, axis='y')
    axes[0].legend(loc='upper right')
    plt.suptitle('Component Score Distributions: Active ASOs vs Controls (thick line = group mean)', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/scoring_diagnosis_distributions.png", dpi=130)
    print("\n Saved figures/scoring_diagnosis_distributions.png")

    plt.figure(figsize=(9, 5))
    names = list(contributions.keys())
    values = list(contributions.values())
    colors = ['#c0392b' if v < 0 else '#2ecc71' for v in values]
    bars = plt.barh(names, values, color=colors)
    plt.axvline(0, color='black', linewidth=0.8)
    plt.xlabel('Weighted contribution to (active - control) score gap')
    plt.title('Which Component Causes the Inverted Ranking?\n(negative = pushes controls above actives)')
    for bar, v in zip(bars, values):
        plt.text(v + (0.002 if v >= 0 else -0.002), bar.get_y()+bar.get_height()/2, f"{v:+.4f}",
                 va='center', ha='left' if v >= 0 else 'right', fontsize=10, fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/scoring_diagnosis_contributions.png", dpi=130)
    print(" Saved figures/scoring_diagnosis_contributions.png")

    diagnosis = {
        "active_mean_combined": float(active['Combined_Score'].mean()),
        "control_mean_combined": float(control['Combined_Score'].mean()),
        "score_gap": float(active['Combined_Score'].mean() - control['Combined_Score'].mean()),
        "weighted_contributions": {k: float(v) for k, v in contributions.items()},
        "worst_component": worst_component,
        "gap_excluding_8mer_outlier": float(gap_no8mer),
        "worst_component_excluding_outlier": worst_no8mer,
    }
    import json
    with open("results/scoring_diagnosis.json", "w", encoding="utf-8") as f:
        json.dump(diagnosis, f, ensure_ascii=False, indent=2)
    print("\n Saved results/scoring_diagnosis.json")
