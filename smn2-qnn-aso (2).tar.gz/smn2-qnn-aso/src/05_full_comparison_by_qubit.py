import sys
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

sys.path.insert(0, "src")
from importlib import import_module
ablation_module = import_module("04_qubit_ablation")

extract_features = ablation_module.extract_features
CONFIGS = ablation_module.CONFIGS
FEATURES_CSV = ablation_module.FEATURES_CSV
TEST_SIZE = ablation_module.TEST_SIZE
SEED = ablation_module.SEED
TRAIN_SUBSET_SIZE = ablation_module.TRAIN_SUBSET_SIZE

QNN_RESULTS_FILE = "results/qubit_ablation_results.json"


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    y = df['label'].values

    idx_all = np.arange(len(df))
    idx_train_full, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)
    rng = np.random.default_rng(SEED)
    pos_train_all = idx_train_full[y[idx_train_full] == 1]
    neg_train_all = idx_train_full[y[idx_train_full] == 0]
    n_pos_target = min(len(pos_train_all), TRAIN_SUBSET_SIZE // 2)
    n_neg_target = TRAIN_SUBSET_SIZE - n_pos_target
    pos_selected = rng.choice(pos_train_all, size=n_pos_target, replace=False)
    neg_selected = rng.choice(neg_train_all, size=min(n_neg_target, len(neg_train_all)), replace=False)
    idx_train = np.concatenate([pos_selected, neg_selected])
    rng.shuffle(idx_train)

    y_train, y_test = y[idx_train], y[idx_test]
    print(f" Train: {len(idx_train)} (positive={int(y_train.sum())}) | Test: {len(idx_test)} (positive={int(y_test.sum())})\n")

    baseline = compute_metrics(y_test, np.zeros_like(y_test))

    with open(QNN_RESULTS_FILE, "r", encoding="utf-8") as f:
        qnn_results = {r["n_qubits"]: r for r in json.load(f)}

    all_results = []
    for config in CONFIGS:
        n_qubits, mode = config["n_qubits"], config["mode"]
        print(f"--- Training SVM/MLP for {n_qubits} qubits ({mode}) ---")

        X = extract_features(df, mode, n_qubits)
        X_train, X_test = X[idx_train], X[idx_test]

        svm_model = SVC(kernel='rbf', class_weight='balanced')
        svm_model.fit(X_train, y_train)
        svm_metric = compute_metrics(y_test, svm_model.predict(X_test))

        pos_idx = np.where(y_train == 1)[0]
        repeat = max(1, len(y_train) // (len(pos_idx) * 2)) if len(pos_idx) > 0 else 1
        X_train_bal = np.vstack([X_train] + [X_train[pos_idx]] * repeat) if len(pos_idx) > 0 else X_train
        y_train_bal = np.concatenate([y_train] + [y_train[pos_idx]] * repeat) if len(pos_idx) > 0 else y_train
        mlp_model = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=1000, random_state=42)
        mlp_model.fit(X_train_bal, y_train_bal)
        mlp_metric = compute_metrics(y_test, mlp_model.predict(X_test))

        qnn_metric = {
            "accuracy": qnn_results[n_qubits]["test_accuracy"],
            "precision": qnn_results[n_qubits]["test_precision"],
            "recall": qnn_results[n_qubits]["test_recall"],
            "f1": qnn_results[n_qubits]["test_f1"],
        }

        print(f"   Baseline: Acc={baseline['accuracy']*100:.1f}% F1={baseline['f1']:.3f}")
        print(f"   SVM     : Acc={svm_metric['accuracy']*100:.1f}% F1={svm_metric['f1']:.3f}")
        print(f"   MLP     : Acc={mlp_metric['accuracy']*100:.1f}% F1={mlp_metric['f1']:.3f}")
        print(f"   QNN     : Acc={qnn_metric['accuracy']*100:.1f}% F1={qnn_metric['f1']:.3f}\n")

        all_results.append({"n_qubits": n_qubits, "mode": mode, "baseline": baseline,
                             "svm": svm_metric, "mlp": mlp_metric, "qnn": qnn_metric})

    with open("results/full_comparison_results.json", "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)

    rows = []
    for r in all_results:
        for model_name in ["baseline", "svm", "mlp", "qnn"]:
            m = r[model_name]
            rows.append({"Qubits": r["n_qubits"], "Model": model_name.upper(),
                         "Accuracy": round(m["accuracy"]*100, 1), "Precision": round(m["precision"], 3),
                         "Recall": round(m["recall"], 3), "F1": round(m["f1"], 3)})
    df_summary = pd.DataFrame(rows)
    print("\n=== SUMMARY TABLE ===")
    print(df_summary.to_string(index=False))
    df_summary.to_csv("results/full_comparison_summary.csv", index=False)

    qubit_counts = [c["n_qubits"] for c in CONFIGS]
    model_names = ["baseline", "svm", "mlp", "qnn"]
    model_labels = ["Baseline", "SVM", "MLP", "QNN"]
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986']

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    width = 0.2
    x = np.arange(len(qubit_counts))

    for i, (model_name, label, color) in enumerate(zip(model_names, model_labels, colors)):
        f1_values = [r[model_name]["f1"] for r in all_results]
        acc_values = [r[model_name]["accuracy"]*100 for r in all_results]
        ax1.bar(x + i*width, f1_values, width, label=label, color=color)
        ax2.bar(x + i*width, acc_values, width, label=label, color=color)

    ax1.set_xlabel('Qubits / Feature Count')
    ax1.set_ylabel('F1 Score (positive class)')
    ax1.set_title('F1 Score by Configuration (Classical vs Quantum)')
    ax1.set_xticks(x + 1.5*width)
    ax1.set_xticklabels([str(q) for q in qubit_counts])
    ax1.legend()
    ax1.grid(alpha=0.3, axis='y')

    ax2.set_xlabel('Qubits / Feature Count')
    ax2.set_ylabel('Test Accuracy (%)')
    ax2.set_title('Accuracy by Configuration (Classical vs Quantum)')
    ax2.set_xticks(x + 1.5*width)
    ax2.set_xticklabels([str(q) for q in qubit_counts])
    ax2.legend()
    ax2.grid(alpha=0.3, axis='y')

    plt.suptitle(f'Full Model Comparison by Qubit Count (N_test={len(idx_test)}, N_train={len(idx_train)})', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/full_comparison_by_qubit.png", dpi=130)
    print("\n Saved figures/full_comparison_by_qubit.png")
