import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from scipy.optimize import minimize

import sys
sys.path.insert(0, "src")
from importlib import import_module
fair_module = import_module("11_fair_comparison_matched_window")

build_circuit = fair_module.build_circuit
prob_one = fair_module.prob_one
learn_pwm = fair_module.learn_pwm
pwm_log_odds = fair_module.pwm_log_odds
find_best_threshold = fair_module.find_best_threshold
CENTER_START = fair_module.CENTER_START
CENTER_END = fair_module.CENTER_END
MATCHED_WINDOW_LEN = fair_module.MATCHED_WINDOW_LEN
N_PARAMS = fair_module.N_PARAMS

FEATURES_CSV = "results/quantum_features.csv"
GENES = ["SMN2", "BRCA1", "TP53", "CFTR", "HBB"]
SEED = 42
QNN_TRAIN_SUBSET = 100
MAXITER = 20
SHOTS = 150


def build_noise_model():
    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.001, 1), ['rx', 'ry', 'rz'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.01, 2), ['cx'])
    return noise_model


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


def train_evaluate_qnn(X_train, y_train, X_test, y_test, sim, seed=SEED):
    rng = np.random.default_rng(seed)
    n = len(X_train)
    size = min(QNN_TRAIN_SUBSET, n)
    if size < 4:
        return compute_metrics(y_test, np.zeros_like(y_test))
    selected = rng.choice(n, size=size, replace=False)
    X_sub, y_sub = X_train[selected], y_train[selected]
    if y_sub.sum() == 0 or y_sub.sum() == len(y_sub):
        pos_idx = np.where(y_train == 1)[0]
        neg_idx = np.where(y_train == 0)[0]
        take_pos = min(len(pos_idx), size // 2)
        take_neg = min(len(neg_idx), size - take_pos)
        X_sub = np.vstack([X_train[pos_idx[:take_pos]], X_train[neg_idx[:take_neg]]])
        y_sub = np.concatenate([y_train[pos_idx[:take_pos]], y_train[neg_idx[:take_neg]]])

    def cost(params):
        total = 0.0
        for i in range(len(X_sub)):
            p1 = prob_one(sim, params, X_sub[i])
            total += (p1 - y_sub[i]) ** 2
        return total / len(X_sub)

    np.random.seed(seed)
    init = np.random.rand(N_PARAMS) * 2 * np.pi
    res = minimize(cost, init, method='COBYLA', options={'maxiter': MAXITER})

    preds = []
    for i in range(len(X_test)):
        p1 = prob_one(sim, res.x, X_test[i])
        preds.append(1 if p1 >= 0.5 else 0)
    return compute_metrics(y_test, preds)


def run_pwm(df_train, df_test, y_test):
    total_preds = np.zeros(len(df_test), dtype=int)
    for site_type in ['donor', 'acceptor']:
        train_type = df_train[df_train['site_type'] == site_type]
        test_mask = (df_test['site_type'] == site_type).values
        pos_w = train_type[train_type['label'] == 1]['matched_window'].tolist()
        neg_w = train_type[train_type['label'] == 0]['matched_window'].tolist()
        if len(pos_w) < 2 or len(neg_w) < 2:
            continue
        pos_pwm = learn_pwm(pos_w, MATCHED_WINDOW_LEN)
        bg_pwm = learn_pwm(neg_w, MATCHED_WINDOW_LEN)
        train_scores = np.array([pwm_log_odds(w, pos_pwm, bg_pwm) for w in train_type['matched_window']])
        threshold, _ = find_best_threshold(train_scores, train_type['label'].values)
        test_windows = df_test.loc[test_mask, 'matched_window']
        test_scores = np.array([pwm_log_odds(w, pos_pwm, bg_pwm) for w in test_windows])
        total_preds[test_mask] = (test_scores >= threshold).astype(int)
    return compute_metrics(y_test, total_preds)


RESULTS_FILE = "results/gene_holdout_results.json"


def load_results():
    import os
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_result(new_result):
    results = load_results()
    results = [r for r in results if r["held_out_gene"] != new_result["held_out_gene"]]
    results.append(new_result)
    order = {g: i for i, g in enumerate(GENES)}
    results.sort(key=lambda r: order.get(r["held_out_gene"], 99))
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    return results


if __name__ == "__main__":
    import sys as _sys
    df = pd.read_csv(FEATURES_CSV)
    df['matched_window'] = df['window'].str[CENTER_START:CENTER_END]
    matched_cols = [f'angle_{i}' for i in range(CENTER_START, CENTER_END)]

    sim = AerSimulator(noise_model=build_noise_model())

    if len(_sys.argv) > 1:
        target_genes = [GENES[int(_sys.argv[1])]]
    else:
        target_genes = GENES

    for held_out_gene in target_genes:
        print(f"\n{'='*60}\n HOLDOUT GENE: {held_out_gene}\n{'='*60}")
        df_train = df[df['gene'] != held_out_gene].reset_index(drop=True)
        df_test = df[df['gene'] == held_out_gene].reset_index(drop=True)

        y_train = df_train['label'].values
        y_test = df_test['label'].values
        print(f" Train genes: {sorted(df_train['gene'].unique())} -> {len(df_train)} windows "
              f"(positive={int(y_train.sum())})")
        print(f" Test gene: {held_out_gene} -> {len(df_test)} windows (positive={int(y_test.sum())})")

        if y_test.sum() == 0:
            print(" WARNING: held-out gene has zero positive examples, skipping.")
            continue

        X_train = df_train[matched_cols].values
        X_test = df_test[matched_cols].values

        baseline = compute_metrics(y_test, np.zeros_like(y_test))

        svm_model = SVC(kernel='rbf', class_weight='balanced')
        svm_model.fit(X_train, y_train)
        svm_metric = compute_metrics(y_test, svm_model.predict(X_test))

        pos_idx = np.where(y_train == 1)[0]
        repeat = max(1, len(y_train) // (len(pos_idx) * 2)) if len(pos_idx) > 0 else 1
        X_train_bal = np.vstack([X_train] + [X_train[pos_idx]] * repeat) if len(pos_idx) > 0 else X_train
        y_train_bal = np.concatenate([y_train] + [y_train[pos_idx]] * repeat) if len(pos_idx) > 0 else y_train
        mlp_model = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=1000, random_state=42)
        mlp_model.fit(X_train_bal, y_train_bal)
        mlp_metric = compute_metrics(y_test, mlp_model.predict(X_test))

        print(" Training QNN on held-in genes...")
        qnn_metric = train_evaluate_qnn(X_train, y_train, X_test, y_test, sim)

        pwm_metric = run_pwm(df_train, df_test, y_test)

        print(f" Baseline: F1={baseline['f1']:.3f} | SVM: F1={svm_metric['f1']:.3f} | "
              f"MLP: F1={mlp_metric['f1']:.3f} | QNN: F1={qnn_metric['f1']:.3f} | PWM: F1={pwm_metric['f1']:.3f}")

        result = {
            "held_out_gene": held_out_gene, "n_train": len(df_train), "n_test": len(df_test),
            "n_test_positive": int(y_test.sum()),
            "baseline": baseline, "svm": svm_metric, "mlp": mlp_metric,
            "qnn": qnn_metric, "pwm": pwm_metric
        }
        results = save_result(result)
        print(f" -> Saved. Completed holdout folds: {len(results)}/{len(GENES)}")

    all_fold_results = load_results()
    if len(all_fold_results) < len(GENES):
        print(f"\n {len(all_fold_results)}/{len(GENES)} holdout genes completed. "
              f"Run remaining ones (index 0-{len(GENES)-1}).")
        import sys as _sys2
        _sys2.exit(0)

    rows = []
    for r in all_fold_results:
        for model_name in ["baseline", "svm", "mlp", "qnn", "pwm"]:
            m = r[model_name]
            rows.append({"Held-out gene": r["held_out_gene"], "N_test": r["n_test"],
                         "N_test_positive": r["n_test_positive"], "Model": model_name.upper(),
                         "Accuracy": round(m["accuracy"]*100, 1), "Precision": round(m["precision"], 3),
                         "Recall": round(m["recall"], 3), "F1": round(m["f1"], 3)})
    df_summary = pd.DataFrame(rows)
    print("\n=== GENE-LEVEL HOLDOUT SUMMARY ===")
    print(df_summary.to_string(index=False))
    df_summary.to_csv("results/gene_holdout_summary.csv", index=False)

    model_names = ["baseline", "svm", "mlp", "qnn", "pwm"]
    model_labels = ["Baseline", "SVM", "MLP", "QNN", "PWM"]
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986', '#e67e22']
    genes_tested = [r["held_out_gene"] for r in all_fold_results]

    fig, ax = plt.subplots(figsize=(13, 6))
    x = np.arange(len(genes_tested))
    width = 0.15
    for i, (model_name, label, color) in enumerate(zip(model_names, model_labels, colors)):
        values = [r[model_name]["f1"] for r in all_fold_results]
        bars = ax.bar(x + i*width, values, width, label=label, color=color)
        for bar, v in zip(bars, values):
            ax.text(bar.get_x()+bar.get_width()/2, v+0.01, f"{v:.2f}", ha='center', fontsize=7)

    ax.set_xlabel('Held-out Gene')
    ax.set_ylabel('F1 Score (positive class)')
    ax.set_title('Gene-Level Holdout: F1 Score by Held-out Gene (train on remaining 4 genes)')
    ax.set_xticks(x + 2*width)
    ax.set_xticklabels(genes_tested)
    ax.legend()
    ax.grid(alpha=0.3, axis='y')
    plt.tight_layout()
    plt.savefig("figures/gene_holdout_comparison.png", dpi=130)
    print("\n Saved figures/gene_holdout_comparison.png")

    print("\n=== MEAN ACROSS HELD-OUT GENES ===")
    for model_name, label in zip(model_names, model_labels):
        f1s = [r[model_name]["f1"] for r in all_fold_results]
        print(f" {label:10s}: mean F1 = {np.mean(f1s):.3f} (± {np.std(f1s):.3f})")
