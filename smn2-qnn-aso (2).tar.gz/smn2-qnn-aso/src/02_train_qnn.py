import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from scipy.optimize import minimize

FEATURES_CSV = "results/quantum_features.csv"
N_QUBITS = 4
N_LAYERS = 2
N_PARAMS = N_QUBITS * N_LAYERS * 2
SHOTS = 400
TEST_SIZE = 0.20
SEED = 42


def build_circuit(angles, params, n_qubits=N_QUBITS, n_layers=N_LAYERS):
    qc = QuantumCircuit(n_qubits, 1)
    for i in range(n_qubits):
        qc.rx(angles[i], i)
    qc.barrier()
    idx = 0
    for l in range(n_layers):
        for i in range(n_qubits):
            qc.ry(params[idx], i)
            qc.rz(params[idx + 1], i)
            idx += 2
        for i in range(n_qubits):
            qc.cx(i, (i + 1) % n_qubits)
        qc.barrier()
    qc.measure(n_qubits - 1, 0)
    return qc


def build_noise_model():
    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.001, 1), ['rx', 'ry', 'rz'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.01, 2), ['cx'])
    return noise_model


def prob_one(sim, params, angles, shots=SHOTS):
    qc = build_circuit(angles, params)
    result = sim.run(qc, shots=shots).result()
    counts = result.get_counts(qc)
    return counts.get('1', 0) / shots


def cost_function(params, sim, X_train, y_train):
    total = 0.0
    for i in range(len(X_train)):
        pred = prob_one(sim, params, X_train[i])
        total += (pred - y_train[i]) ** 2
    avg = total / len(X_train)
    print(f"  [Train] Loss: {avg:.4f}")
    return avg


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    feature_cols = [f'angle_{i}' for i in range(N_QUBITS)]
    X = df[feature_cols].values
    y = df['label'].values

    print(f" Total dataset: {len(df)} rows | Class balance: {dict(zip(*np.unique(y, return_counts=True)))}")

    idx_all = np.arange(len(df))
    idx_train, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)
    X_train, y_train = X[idx_train], y[idx_train]
    X_test, y_test = X[idx_test], y[idx_test]

    print(f" Train: {len(X_train)} (positive={int(y_train.sum())}) | Test: {len(X_test)} (positive={int(y_test.sum())})")

    sim = AerSimulator(noise_model=build_noise_model())
    np.random.seed(SEED)
    init_params = np.random.rand(N_PARAMS) * 2 * np.pi

    print("\n Starting COBYLA optimization under IBM noise model (train set only)...")
    res = minimize(cost_function, init_params, args=(sim, X_train, y_train),
                    method='COBYLA', options={'maxiter': 40})

    print(f"\n Training finished. Final train loss: {res.fun:.4f}")

    output = {
        "opt_params": res.x.tolist(),
        "final_train_loss": float(res.fun),
        "feature_cols": feature_cols,
        "n_qubits": N_QUBITS,
        "n_layers": N_LAYERS,
        "shots": SHOTS,
        "seed": SEED,
        "test_size": TEST_SIZE,
        "idx_train": idx_train.tolist(),
        "idx_test": idx_test.tolist(),
        "features_csv": FEATURES_CSV
    }
    with open("results/qnn_trained_parameters.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(" Saved results/qnn_trained_parameters.json")
