import json
import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from scipy.optimize import minimize

sys.path.insert(0, "src")
from importlib import import_module
ablation_module = import_module("04_qubit_ablation")

extract_features = ablation_module.extract_features
prob_one = ablation_module.prob_one
FEATURES_CSV = ablation_module.FEATURES_CSV

N_QUBITS = 6
N_LAYERS = 2
N_PARAMS = N_QUBITS * N_LAYERS * 2
MODE = "truncate"
SHOTS = 150
MAXITER = 20
N_FOLDS = 5
SEED = 42
TRAIN_SUBSET_SIZE = 100

RESULTS_FILE = "results/cross_validation_6qubit_folds.json"


def build_noise_model():
    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.001, 1), ['rx', 'ry', 'rz'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.01, 2), ['cx'])
    return noise_model


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


def load_results():
    if os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_result(new_result):
    results = load_results()
    results = [r for r in results if r["fold"] != new_result["fold"]]
    results.append(new_result)
    results.sort(key=lambda r: r["fold"])
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    return results


def run_fold(fold_no, idx_train_full, idx_test, df, y, sim):
    print(f"\n{'='*55}\n FOLD {fold_no + 1}/{N_FOLDS}\n{'='*55}")

    rng = np.random.default_rng(SEED + fold_no)
    pos_train_all = idx_train_full[y[idx_train_full] == 1]
    neg_train_all = idx_train_full[y[idx_train_full] == 0]
    n_pos_target = min(len(pos_train_all), TRAIN_SUBSET_SIZE // 2)
    n_neg_target = TRAIN_SUBSET_SIZE - n_pos_target
    pos_selected = rng.choice(pos_train_all, size=n_pos_target, replace=False)
    neg_selected = rng.choice(neg_train_all, size=min(n_neg_target, len(neg_train_all)), replace=False)
    idx_train = np.concatenate([pos_selected, neg_selected])
    rng.shuffle(idx_train)

    y_train, y_test = y[idx_train], y[idx_test]
    print(f" Train: {len(idx_train)} (positive={int(y_train.sum())}) | Test: {len(idx_test)} (positive={int(y_test.sum())})")

    X = extract_features(df, MODE, N_QUBITS)
    X_train, X_test = X[idx_train], X[idx_test]

    baseline = compute_metrics(y_test, np.zeros_like(y_test))

    svm_model = SVC(kernel='rbf', class_weight='balanced')
    svm_model.fit(X_train, y_train)
    svm_metric = compute_metrics(y_test, svm_model.predict(X_test))

    pos_idx = np.where(y_train == 1)[0]
    repeat = max(1, len(y_train) // (len(pos_idx) * 2)) if len(pos_idx) > 0 else 1
    X_train_bal = np.vstack([X_train] + [X_train[pos_idx]] * repeat) if len(pos_idx) > 0 else X_train
    y_train_bal = np.concatenate([y_train] + [y_train[pos_idx]] * repeat) if len(pos_idx) > 0 else y_train
    mlp_model = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=1000, random_state=42)
    mlp_model.fit(X_train_bal, y_train_bal)
    mlp_metric = compute_metrics(y_test, mlp_model.predict(X_test))

    def cost(params):
        total = 0.0
        for i in range(len(X_train)):
            p1 = prob_one(sim, params, X_train[i], N_QUBITS, N_LAYERS, shots=SHOTS)
            total += (p1 - y_train[i]) ** 2
        return total / len(X_train)

    np.random.seed(SEED + fold_no)
    init = np.random.rand(N_PARAMS) * 2 * np.pi
    res = minimize(cost, init, method='COBYLA', options={'maxiter': MAXITER})

    qnn_preds = []
    for i in range(len(X_test)):
        p1 = prob_one(sim, res.x, X_test[i], N_QUBITS, N_LAYERS, shots=SHOTS)
        qnn_preds.append(1 if p1 >= 0.5 else 0)
    qnn_metric = compute_metrics(y_test, qnn_preds)

    print(f" Baseline F1={baseline['f1']:.3f} | SVM F1={svm_metric['f1']:.3f} | "
          f"MLP F1={mlp_metric['f1']:.3f} | QNN F1={qnn_metric['f1']:.3f}")

    return {"fold": fold_no, "baseline": baseline, "svm": svm_metric,
            "mlp": mlp_metric, "qnn": qnn_metric,
            "n_train": len(idx_train), "n_test": len(idx_test)}


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    y = df['label'].values

    skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    fold_splits = list(skf.split(np.zeros(len(y)), y))

    sim = AerSimulator(noise_model=build_noise_model())

    if len(sys.argv) > 1:
        fold_no = int(sys.argv[1])
        idx_train_full, idx_test = fold_splits[fold_no]
        result = run_fold(fold_no, idx_train_full, idx_test, df, y, sim)
        results = save_result(result)
        print(f"\n Saved. Completed folds: {len(results)}/{N_FOLDS}")
        sys.exit(0)

    results = load_results()
    if len(results) < N_FOLDS:
        print(f" {len(results)}/{N_FOLDS} folds completed. Run remaining folds (0-{N_FOLDS-1}).")
        sys.exit(0)

    print(" All folds completed, computing summary...\n")
    model_names = ["baseline", "svm", "mlp", "qnn"]
    summary = {}
    for model_name in model_names:
        f1_list = [r[model_name]["f1"] for r in results]
        acc_list = [r[model_name]["accuracy"] for r in results]
        rec_list = [r[model_name]["recall"] for r in results]
        summary[model_name] = {
            "f1_mean": float(np.mean(f1_list)), "f1_std": float(np.std(f1_list)),
            "accuracy_mean": float(np.mean(acc_list)), "accuracy_std": float(np.std(acc_list)),
            "recall_mean": float(np.mean(rec_list)), "recall_std": float(np.std(rec_list)),
            "f1_all_folds": f1_list
        }
        print(f" {model_name.upper():10s}: F1 = {summary[model_name]['f1_mean']:.3f} ± "
              f"{summary[model_name]['f1_std']:.3f}  (folds: {[round(x,3) for x in f1_list]})")

    with open("results/cross_validation_6qubit_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    plt.figure(figsize=(8, 5.5))
    data = [summary[m]["f1_all_folds"] for m in model_names]
    labels = ["Baseline", "SVM", "MLP", "QNN (6 qubits)"]
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986']
    bp = plt.boxplot(data, tick_labels=labels, patch_artist=True, widths=0.5)
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
    for i, f1_list in enumerate(data):
        x_jitter = np.random.normal(i + 1, 0.04, size=len(f1_list))
        plt.scatter(x_jitter, f1_list, color='black', s=25, zorder=3, alpha=0.7)
    plt.ylabel('F1 Score (positive class)')
    plt.title(f'6-Qubit QNN vs Classical Models: {N_FOLDS}-Fold Cross-Validation Stability')
    plt.grid(alpha=0.3, axis='y')
    plt.tight_layout()
    plt.savefig("figures/cross_validation_6qubit_boxplot.png", dpi=130)
    print("\n Saved figures/cross_validation_6qubit_boxplot.png")
