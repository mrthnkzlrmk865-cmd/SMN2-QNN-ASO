import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from Bio import SeqIO
from scipy.stats import mannwhitneyu

import sys
sys.path.insert(0, "src")
from importlib import import_module
qnn_module = import_module("02_train_qnn")
aso_module = import_module("10_design_aso_candidates")

prob_one = qnn_module.prob_one
base_to_radian = aso_module.base_to_radian
reverse_complement = aso_module.reverse_complement
duplex_delta_g = aso_module.duplex_delta_g
gc_content = aso_module.gc_content
off_target_scan = aso_module.off_target_scan
N_QUBITS = aso_module.N_QUBITS

from qiskit_aer import AerSimulator

GENOMIC_FASTA = "data/smn2_genomic.fasta"


def qnn_scan_window(rna_seq, opt_params, shots=400):
    seq = ''.join(c for c in rna_seq.upper().replace('T', 'U') if c in 'AUGC')
    sim = AerSimulator()
    probs = []
    for i in range(len(seq) - N_QUBITS + 1):
        window = seq[i:i + N_QUBITS]
        angles = [base_to_radian(b) for b in window]
        p1 = prob_one(sim, opt_params, angles, shots=shots)
        probs.append(p1)
    return (float(np.mean(probs)) if probs else 0.0)


if __name__ == "__main__":
    with open("results/qnn_trained_parameters.json", "r", encoding="utf-8") as f:
        train_info = json.load(f)
    opt_params = np.array(train_info["opt_params"])

    record = next(SeqIO.parse(GENOMIC_FASTA, "fasta"))
    genomic = str(record.seq).upper()
    intron7 = genomic[32052:32496]
    gc_core_target = intron7[6:14].replace('T', 'U')

    known_aso_dna = {
        "Nusinersen / ASO-10-27": ("TCACTTTCATAATGCTGG", "active",
            "FDA-approved ISS-N1-targeting ASO; Rigo/Krainer/Bennett; fully restores SMN2 exon 7 inclusion."),
        "Anti-N1 (Singh et al. discovery ASO)": ("ATTCACTTTCATAATGCTGG", "active",
            "Original 20-mer that established ISS-N1 as a therapeutic target; restored exon 7 inclusion at 5 nM."),
        "8-mer GC-core ASO (position-matched, Singh et al. 2009)": (
            str(reverse_complement(gc_core_target)).replace('U', 'T'), "active",
            "Exact published sequence not recovered from search; target region (intron 7, position 7-14) "
            "is literature-confirmed, ASO sequence derived here as the reverse complement of that region "
            "in our own genomic data, not copied from a paper."),
        "Scrambled control (constructed)": (None, "control",
            "Same base composition as Nusinersen, order shuffled (seed=42); not from a specific publication."),
        "Off-target control (unrelated SMN2 region)": (None, "control",
            "Reverse complement of a randomly chosen SMN2 exon-1-region window, unrelated to ISS-N1."),
        "ISS-N2-targeting ASO (different silencer)": ("AAGTCTGCTGGTCTGCCTAC", "control",
            "Targets a distinct silencer element (ISS-N2), not ISS-N1; expected to score low on this "
            "ISS-N1-specific pipeline regardless of its own real-world activity at its own target."),
    }

    rng = np.random.default_rng(42)
    scrambled = list("TCACTTTCATAATGCTGG")
    rng.shuffle(scrambled)
    known_aso_dna["Scrambled control (constructed)"] = (
        "".join(scrambled), "control", known_aso_dna["Scrambled control (constructed)"][2])

    off_target_region_dna = genomic[5146:5146+18]
    known_aso_dna["Off-target control (unrelated SMN2 region)"] = (
        off_target_region_dna, "control", known_aso_dna["Off-target control (unrelated SMN2 region)"][2])

    results = []
    for name, (dna_seq, category, note) in known_aso_dna.items():
        rna_seq = dna_seq.replace('T', 'U')
        avg_p1 = qnn_scan_window(rna_seq, opt_params)
        delta_g = duplex_delta_g(rna_seq)
        stability = float(np.clip((-delta_g) / 40.0, 0, 1))
        off_risk, matches = off_target_scan(rna_seq, genomic)
        gc = gc_content(rna_seq)
        combined_score = avg_p1 * 0.5 + stability * 0.3 + (1 - off_risk) * 0.2

        print(f"\n{name} [{category}]")
        print(f"  Sequence: 5'-{dna_seq}-3'")
        print(f"  QNN avg P(1)={avg_p1:.3f} | dG={delta_g} kcal/mol | stability={stability:.3f} | "
              f"off-target risk={off_risk:.3f} | combined={combined_score:.3f}")

        results.append({
            "ASO": name, "Sequence": dna_seq, "Category": category, "Note": note,
            "QNN_P1": round(avg_p1, 3), "Delta_G": delta_g, "Stability_Score": round(stability, 3),
            "Off_Target_Risk": round(off_risk, 3), "GC_Content": round(gc, 2),
            "Combined_Score": round(combined_score, 3)
        })

    df = pd.DataFrame(results).sort_values("Combined_Score", ascending=False).reset_index(drop=True)
    df["Rank"] = df.index + 1
    print("\n=== RETROSPECTIVE RANKING (highest combined score first) ===")
    print(df[["Rank", "ASO", "Category", "QNN_P1", "Stability_Score", "Off_Target_Risk", "Combined_Score"]].to_string(index=False))

    active_scores = df[df["Category"] == "active"]["Combined_Score"].values
    control_scores = df[df["Category"] == "control"]["Combined_Score"].values
    active_ranks = df[df["Category"] == "active"]["Rank"].values
    control_ranks = df[df["Category"] == "control"]["Rank"].values

    print(f"\n Active ASOs mean rank: {active_ranks.mean():.2f} (lower = better) | "
          f"Control ASOs mean rank: {control_ranks.mean():.2f}")
    print(f" Active ASOs mean combined score: {active_scores.mean():.3f} | "
          f"Control mean combined score: {control_scores.mean():.3f}")

    if len(active_scores) >= 2 and len(control_scores) >= 2:
        stat, p_value = mannwhitneyu(active_scores, control_scores, alternative='greater')
        print(f" Mann-Whitney U test (active > control): U={stat:.1f}, p={p_value:.3f}")
    else:
        p_value = None
        print(" Sample size too small per group for a formal statistical test (n<2); reporting ranks only.")

    df.to_csv("results/retrospective_aso_validation.csv", index=False)
    with open("results/retrospective_aso_validation.json", "w", encoding="utf-8") as f:
        json.dump({
            "active_mean_rank": float(active_ranks.mean()), "control_mean_rank": float(control_ranks.mean()),
            "active_mean_score": float(active_scores.mean()), "control_mean_score": float(control_scores.mean()),
            "mann_whitney_p": float(p_value) if p_value is not None else None,
            "results": results
        }, f, ensure_ascii=False, indent=2)

    colors = ['#2ecc71' if c == 'active' else '#e74c3c' for c in df['Category']]
    plt.figure(figsize=(11, 6))
    bars = plt.barh(df['ASO'], df['Combined_Score'], color=colors)
    plt.xlabel('Combined Score (0.5×QNN affinity + 0.3×stability + 0.2×(1-off-target risk))')
    plt.title('Retrospective Validation: Published Active ASOs (green) vs Controls (red)')
    plt.gca().invert_yaxis()
    for bar, v in zip(bars, df['Combined_Score']):
        plt.text(v + 0.01, bar.get_y() + bar.get_height()/2, f"{v:.2f}", va='center', fontsize=9)
    plt.tight_layout()
    plt.savefig("figures/retrospective_aso_validation.png", dpi=130)
    print("\n Saved figures/retrospective_aso_validation.png")
