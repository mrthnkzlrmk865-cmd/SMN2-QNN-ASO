import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

FEATURES_CSV = "results/quantum_features.csv"
TEST_SIZE = 0.20
SEED = 42
PSEUDOCOUNT = 1.0
BASES = ['A', 'U', 'G', 'C']


def to_rna(window):
    return window.upper().replace('T', 'U')


def learn_pwm(windows, length):
    counts = np.full((length, len(BASES)), PSEUDOCOUNT)
    for window in windows:
        window = to_rna(window)
        if len(window) != length:
            continue
        for pos, base in enumerate(window):
            if base in BASES:
                counts[pos, BASES.index(base)] += 1
    probs = counts / counts.sum(axis=1, keepdims=True)
    return probs


def log_odds_score(window, positive_pwm, background_pwm):
    window = to_rna(window)
    score = 0.0
    for pos, base in enumerate(window):
        if base not in BASES or pos >= positive_pwm.shape[0]:
            continue
        b_idx = BASES.index(base)
        p_pos = positive_pwm[pos, b_idx]
        p_bg = background_pwm[pos, b_idx]
        score += np.log(p_pos / p_bg)
    return score


def find_best_threshold(scores, labels):
    candidates = np.unique(scores)
    best_threshold, best_f1 = 0.0, -1
    for threshold in candidates:
        pred = (scores >= threshold).astype(int)
        f1 = f1_score(labels, pred, zero_division=0)
        if f1 > best_f1:
            best_f1, best_threshold = f1, threshold
    return best_threshold, best_f1


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    y = df['label'].values
    window_length = len(to_rna(df['window'].iloc[0]))

    idx_all = np.arange(len(df))
    idx_train, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)
    df_train = df.iloc[idx_train].reset_index(drop=True)
    df_test = df.iloc[idx_test].reset_index(drop=True)
    print(f" Train: {len(df_train)} (positive={int(df_train['label'].sum())}) | "
          f"Test: {len(df_test)} (positive={int(df_test['label'].sum())})")

    total_test_preds = np.zeros(len(df_test), dtype=int)

    for site_type in ['donor', 'acceptor']:
        print(f"\n--- Learning {site_type.upper()} PWM ---")
        train_type = df_train[df_train['site_type'] == site_type]
        test_type_mask = (df_test['site_type'] == site_type).values

        positive_windows = train_type[train_type['label'] == 1]['window'].tolist()
        negative_windows = train_type[train_type['label'] == 0]['window'].tolist()
        print(f" Train {site_type}: {len(positive_windows)} positive, {len(negative_windows)} negative")

        positive_pwm = learn_pwm(positive_windows, window_length)
        background_pwm = learn_pwm(negative_windows, window_length)

        train_scores = np.array([log_odds_score(w, positive_pwm, background_pwm) for w in train_type['window']])
        train_labels = train_type['label'].values
        threshold, train_f1 = find_best_threshold(train_scores, train_labels)
        print(f" Best threshold on train: {threshold:.3f} (train F1={train_f1:.3f})")

        test_windows = df_test.loc[test_type_mask, 'window']
        test_scores = np.array([log_odds_score(w, positive_pwm, background_pwm) for w in test_windows])
        test_preds = (test_scores >= threshold).astype(int)
        total_test_preds[test_type_mask] = test_preds

        type_metric = compute_metrics(df_test.loc[test_type_mask, 'label'].values, test_preds)
        print(f" Test ({site_type}) -> Accuracy={type_metric['accuracy']*100:.1f}% F1={type_metric['f1']:.3f}")

    y_test_all = df_test['label'].values
    pwm_metric = compute_metrics(y_test_all, total_test_preds)
    print(f"\n=== PWM Baseline Overall Test Result ===")
    print(f" Accuracy: {pwm_metric['accuracy']*100:.2f}%")
    print(f" Precision: {pwm_metric['precision']:.3f} | Recall: {pwm_metric['recall']:.3f} | F1: {pwm_metric['f1']:.3f}")

    try:
        with open("results/benchmark_results.json", "r", encoding="utf-8") as f:
            previous = json.load(f)
        comparison = {
            "Baseline": previous["baseline"],
            "SVM (4 features)": previous["svm"],
            "MLP (4 features)": previous["mlp"],
            "QNN (4 qubits)": previous["qnn"],
            "PWM (domain-specific)": pwm_metric,
        }
        for name, m in comparison.items():
            print(f" {name:30s}: Acc={m['accuracy']*100:5.1f}%  F1={m['f1']:.3f}  Recall={m['recall']:.3f}")

        with open("results/pwm_comparison_results.json", "w", encoding="utf-8") as f:
            json.dump(comparison, f, ensure_ascii=False, indent=2)

        names = list(comparison.keys())
        f1_values = [comparison[k]['f1'] for k in names]
        acc_values = [comparison[k]['accuracy']*100 for k in names]
        colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986', '#e67e22']

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5))
        bars1 = ax1.bar(range(len(names)), f1_values, color=colors)
        ax1.set_xticks(range(len(names)))
        ax1.set_xticklabels(names, rotation=20, ha='right', fontsize=9)
        ax1.set_ylabel('F1 Score')
        ax1.set_title('F1 Score (PWM baseline included)')
        ax1.grid(alpha=0.3, axis='y')
        for bar, v in zip(bars1, f1_values):
            ax1.text(bar.get_x()+bar.get_width()/2, v+0.01, f"{v:.2f}", ha='center', fontsize=8, fontweight='bold')

        bars2 = ax2.bar(range(len(names)), acc_values, color=colors)
        ax2.set_xticks(range(len(names)))
        ax2.set_xticklabels(names, rotation=20, ha='right', fontsize=9)
        ax2.set_ylabel('Accuracy (%)')
        ax2.set_title('Accuracy (PWM baseline included)')
        ax2.grid(alpha=0.3, axis='y')
        for bar, v in zip(bars2, acc_values):
            ax2.text(bar.get_x()+bar.get_width()/2, v+1, f"{v:.1f}%", ha='center', fontsize=8, fontweight='bold')

        plt.suptitle('Classical Domain-Specific (PWM) Baseline Included', fontweight='bold')
        plt.tight_layout()
        plt.savefig("figures/pwm_baseline_comparison.png", dpi=130)
        print("\n Saved figures/pwm_baseline_comparison.png")

    except FileNotFoundError:
        print("\n WARNING: results/benchmark_results.json not found, run 03_benchmark first.")
