import json
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error
from scipy.optimize import minimize

FEATURES_CSV = "results/quantum_features.csv"
TEST_SIZE = 0.20
SEED = 42
FULL_WINDOW_LEN = 22
MOTIF_CENTER = 11
MATCHED_WINDOW_LEN = 8
CENTER_START = MOTIF_CENTER - MATCHED_WINDOW_LEN // 2
CENTER_END = CENTER_START + MATCHED_WINDOW_LEN
N_QUBITS = MATCHED_WINDOW_LEN
N_LAYERS = 2
N_PARAMS = N_QUBITS * N_LAYERS * 2
SHOTS = 150
MAXITER = 20
QNN_TRAIN_SUBSET = 100
PSEUDOCOUNT = 1.0
BASES = ['A', 'U', 'G', 'C']


def build_noise_model():
    noise_model = NoiseModel()
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.001, 1), ['rx', 'ry', 'rz'])
    noise_model.add_all_qubit_quantum_error(depolarizing_error(0.01, 2), ['cx'])
    return noise_model


def build_circuit(angles, params, n_qubits=N_QUBITS, n_layers=N_LAYERS):
    qc = QuantumCircuit(n_qubits, 1)
    for i in range(n_qubits):
        qc.rx(angles[i], i)
    qc.barrier()
    idx = 0
    for l in range(n_layers):
        for i in range(n_qubits):
            qc.ry(params[idx], i)
            qc.rz(params[idx + 1], i)
            idx += 2
        for i in range(n_qubits):
            qc.cx(i, (i + 1) % n_qubits)
        qc.barrier()
    qc.measure(n_qubits - 1, 0)
    return qc


def prob_one(sim, params, angles, shots=SHOTS):
    qc = build_circuit(angles, params)
    result = sim.run(qc, shots=shots).result()
    counts = result.get_counts(qc)
    return counts.get('1', 0) / shots


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


def to_rna(window):
    return window.upper().replace('T', 'U')


def learn_pwm(windows, length):
    counts = np.full((length, len(BASES)), PSEUDOCOUNT)
    for window in windows:
        window = to_rna(window)
        if len(window) != length:
            continue
        for pos, base in enumerate(window):
            if base in BASES:
                counts[pos, BASES.index(base)] += 1
    return counts / counts.sum(axis=1, keepdims=True)


def pwm_log_odds(window, positive_pwm, background_pwm):
    window = to_rna(window)
    score = 0.0
    for pos, base in enumerate(window):
        if base not in BASES or pos >= positive_pwm.shape[0]:
            continue
        b = BASES.index(base)
        score += np.log(positive_pwm[pos, b] / background_pwm[pos, b])
    return score


def find_best_threshold(scores, labels):
    candidates = np.unique(scores)
    best_threshold, best_f1 = 0.0, -1
    for threshold in candidates:
        f1 = f1_score(labels, (scores >= threshold).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_threshold = f1, threshold
    return best_threshold, best_f1


def train_evaluate_qnn(X_train, y_train, X_test, y_test, sim, subset_size=QNN_TRAIN_SUBSET, seed=SEED):
    rng = np.random.default_rng(seed)
    n = len(X_train)
    size = min(subset_size, n)
    selected = rng.choice(n, size=size, replace=False)
    X_sub, y_sub = X_train[selected], y_train[selected]

    def cost(params):
        total = 0.0
        for i in range(len(X_sub)):
            p1 = prob_one(sim, params, X_sub[i])
            total += (p1 - y_sub[i]) ** 2
        return total / len(X_sub)

    np.random.seed(seed)
    init = np.random.rand(N_PARAMS) * 2 * np.pi
    res = minimize(cost, init, method='COBYLA', options={'maxiter': MAXITER})

    preds, probs = [], []
    for i in range(len(X_test)):
        p1 = prob_one(sim, res.x, X_test[i])
        probs.append(p1)
        preds.append(1 if p1 >= 0.5 else 0)

    return compute_metrics(y_test, preds), len(X_sub), int(y_sub.sum())


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    y = df['label'].values

    matched_angle_cols = [f'angle_{i}' for i in range(CENTER_START, CENTER_END)]
    df['matched_window'] = df['window'].str[CENTER_START:CENTER_END]
    print(f" Matched window: positions {CENTER_START}-{CENTER_END-1} of the {FULL_WINDOW_LEN}nt window "
          f"(centered on the GT/AG motif at position {MOTIF_CENTER-1}-{MOTIF_CENTER}).")
    print(f" Example matched window: {df['matched_window'].iloc[0]}")

    idx_all = np.arange(len(df))
    idx_train, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)
    df_train, df_test = df.iloc[idx_train].reset_index(drop=True), df.iloc[idx_test].reset_index(drop=True)
    print(f" Train: {len(df_train)} (positive={int(df_train['label'].sum())}) | "
          f"Test: {len(df_test)} (positive={int(df_test['label'].sum())})")

    X = df[matched_angle_cols].values
    X_train_full, X_test_full = X[idx_train], X[idx_test]
    y_train, y_test = y[idx_train], y[idx_test]

    results = {}

    results["Baseline"] = compute_metrics(y_test, np.zeros_like(y_test))
    print(f"\n Baseline: F1={results['Baseline']['f1']:.3f}")

    svm_model = SVC(kernel='rbf', class_weight='balanced')
    svm_model.fit(X_train_full, y_train)
    results["SVM"] = compute_metrics(y_test, svm_model.predict(X_test_full))
    print(f" SVM ({MATCHED_WINDOW_LEN} features): Acc={results['SVM']['accuracy']*100:.1f}% F1={results['SVM']['f1']:.3f}")

    pos_idx = np.where(y_train == 1)[0]
    repeat = max(1, len(y_train) // (len(pos_idx) * 2)) if len(pos_idx) > 0 else 1
    X_train_bal = np.vstack([X_train_full] + [X_train_full[pos_idx]] * repeat) if len(pos_idx) > 0 else X_train_full
    y_train_bal = np.concatenate([y_train] + [y_train[pos_idx]] * repeat) if len(pos_idx) > 0 else y_train
    mlp_model = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=1000, random_state=42)
    mlp_model.fit(X_train_bal, y_train_bal)
    results["MLP"] = compute_metrics(y_test, mlp_model.predict(X_test_full))
    print(f" MLP ({MATCHED_WINDOW_LEN} features): Acc={results['MLP']['accuracy']*100:.1f}% F1={results['MLP']['f1']:.3f}")

    print(f"\n Training QNN ({N_QUBITS} qubits, centered window, {QNN_TRAIN_SUBSET}-sample subset)...")
    sim = AerSimulator(noise_model=build_noise_model())
    qnn_metric, n_qnn_train, n_qnn_pos = train_evaluate_qnn(X_train_full, y_train, X_test_full, y_test, sim)
    results["QNN"] = qnn_metric
    print(f" QNN ({N_QUBITS} qubits): Acc={qnn_metric['accuracy']*100:.1f}% F1={qnn_metric['f1']:.3f} "
          f"(train: {n_qnn_train} samples, {n_qnn_pos} positive)")

    total_pwm_preds = np.zeros(len(df_test), dtype=int)
    total_maxent_preds = np.zeros(len(df_test), dtype=int)

    for site_type in ['donor', 'acceptor']:
        train_type = df_train[df_train['site_type'] == site_type]
        test_type_mask = (df_test['site_type'] == site_type).values

        pos_windows = train_type[train_type['label'] == 1]['matched_window'].tolist()
        neg_windows = train_type[train_type['label'] == 0]['matched_window'].tolist()

        pos_pwm = learn_pwm(pos_windows, MATCHED_WINDOW_LEN)
        bg_pwm = learn_pwm(neg_windows, MATCHED_WINDOW_LEN)
        train_scores = np.array([pwm_log_odds(w, pos_pwm, bg_pwm) for w in train_type['matched_window']])
        threshold, _ = find_best_threshold(train_scores, train_type['label'].values)
        test_windows = df_test.loc[test_type_mask, 'matched_window']
        test_scores = np.array([pwm_log_odds(w, pos_pwm, bg_pwm) for w in test_windows])
        total_pwm_preds[test_type_mask] = (test_scores >= threshold).astype(int)

    results["PWM"] = compute_metrics(y_test, total_pwm_preds)
    print(f" PWM ({MATCHED_WINDOW_LEN}nt matched window): Acc={results['PWM']['accuracy']*100:.1f}% F1={results['PWM']['f1']:.3f}")

    with open("results/pwm_comparison_results.json", "r", encoding="utf-8") as f:
        prior_pwm_full = json.load(f)
    with open("results/final_comparison.json", "r", encoding="utf-8") as f:
        prior_final = json.load(f)
    results["MaxEnt-like"] = prior_final["MaxEnt-like (1st-order Markov/WAM)"]
    print(f" MaxEnt-like (full 22nt window, reference): F1={results['MaxEnt-like']['f1']:.3f}")

    with open("results/fair_comparison_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    df_table = pd.DataFrame([
        {"Model": name, "Feature window": f"{MATCHED_WINDOW_LEN}nt (centered)" if name != "MaxEnt-like" else "22nt (full, reference)",
         "Accuracy(%)": round(m['accuracy']*100, 1), "Precision": round(m['precision'], 3),
         "Recall": round(m['recall'], 3), "F1": round(m['f1'], 3)}
        for name, m in results.items()
    ])
    df_table.to_csv("results/fair_comparison_summary.csv", index=False)
    print("\n=== FAIR COMPARISON TABLE (matched 8nt centered window) ===")
    print(df_table.to_string(index=False))

    names = list(results.keys())
    f1_values = [results[k]['f1'] for k in names]
    acc_values = [results[k]['accuracy']*100 for k in names]
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986', '#e67e22', '#c0392b']

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5))
    bars1 = ax1.bar(names, f1_values, color=colors)
    ax1.set_ylabel('F1 Score')
    ax1.set_title(f'F1 Score — Matched {MATCHED_WINDOW_LEN}nt Centered Window\n(MaxEnt-like shown at full 22nt as reference)')
    ax1.tick_params(axis='x', rotation=20)
    ax1.grid(alpha=0.3, axis='y')
    for bar, v in zip(bars1, f1_values):
        ax1.text(bar.get_x()+bar.get_width()/2, v+0.01, f"{v:.2f}", ha='center', fontsize=9, fontweight='bold')

    bars2 = ax2.bar(names, acc_values, color=colors)
    ax2.set_ylabel('Accuracy (%)')
    ax2.set_title('Accuracy — Matched Feature Budget')
    ax2.tick_params(axis='x', rotation=20)
    ax2.grid(alpha=0.3, axis='y')
    for bar, v in zip(bars2, acc_values):
        ax2.text(bar.get_x()+bar.get_width()/2, v+1, f"{v:.1f}%", ha='center', fontsize=9, fontweight='bold')

    plt.suptitle('Fair Model Comparison: All Models on Matched, Center-Aligned Feature Window', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/fair_comparison_matched_window.png", dpi=130)
    print("\n Saved figures/fair_comparison_matched_window.png")
