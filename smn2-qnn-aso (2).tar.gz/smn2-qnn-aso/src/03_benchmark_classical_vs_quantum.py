import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from qiskit_aer import AerSimulator
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

from importlib import import_module
qnn_module = import_module("02_train_qnn")


def qnn_test_evaluate(opt_params, X_test, y_test, shots=400):
    sim = AerSimulator()
    preds, probs = [], []
    for i in range(len(X_test)):
        p1 = qnn_module.prob_one(sim, opt_params, X_test[i], shots=shots)
        probs.append(p1)
        preds.append(1 if p1 >= 0.5 else 0)
    return np.array(preds), np.array(probs)


def compute_metrics(y_true, y_pred, name):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    print(f"\n {name}:")
    print(f"   Accuracy : {acc*100:.2f}%")
    print(f"   Precision: {prec:.3f}")
    print(f"   Recall   : {rec:.3f}")
    print(f"   F1       : {f1:.3f}")
    return {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1}


if __name__ == "__main__":
    with open("results/qnn_trained_parameters.json", "r", encoding="utf-8") as f:
        train_info = json.load(f)

    opt_params = np.array(train_info["opt_params"])
    feature_cols = train_info["feature_cols"]
    idx_train = np.array(train_info["idx_train"])
    idx_test = np.array(train_info["idx_test"])

    df = pd.read_csv(train_info["features_csv"])
    X = df[feature_cols].values
    y = df['label'].values

    X_train, X_test = X[idx_train], X[idx_test]
    y_train, y_test = y[idx_train], y[idx_test]

    print(f" Features used (identical for all models): {feature_cols}")
    print(f" Train: {len(X_train)} (positive={int(y_train.sum())}) | Test: {len(X_test)} (positive={int(y_test.sum())})")

    baseline_preds = np.zeros_like(y_test)
    baseline = compute_metrics(y_test, baseline_preds, "Baseline (always predict 0)")

    svm_model = SVC(kernel='rbf', class_weight='balanced')
    svm_model.fit(X_train, y_train)
    svm_result = compute_metrics(y_test, svm_model.predict(X_test), "Classical SVM")

    pos_idx = np.where(y_train == 1)[0]
    repeat = max(1, len(y_train) // (len(pos_idx) * 2)) if len(pos_idx) > 0 else 1
    X_train_bal = np.vstack([X_train] + [X_train[pos_idx]] * repeat) if len(pos_idx) > 0 else X_train
    y_train_bal = np.concatenate([y_train] + [y_train[pos_idx]] * repeat) if len(pos_idx) > 0 else y_train
    mlp_model = MLPClassifier(hidden_layer_sizes=(16, 8), max_iter=1000, random_state=42)
    mlp_model.fit(X_train_bal, y_train_bal)
    mlp_result = compute_metrics(y_test, mlp_model.predict(X_test), "Classical MLP/ANN")

    print("\n Evaluating QNN on test set (circuit simulation per sample)...")
    qnn_preds, qnn_probs = qnn_test_evaluate(opt_params, X_test, y_test)
    qnn_result = compute_metrics(y_test, qnn_preds, "Quantum QNN")
    qnn_loss = float(np.mean((qnn_probs - y_test) ** 2))
    print(f"   Test Loss (MSE): {qnn_loss:.4f}")

    models = ['Baseline', 'SVM', 'MLP', 'QNN\n(4 qubits)']
    acc_scores = [baseline['accuracy']*100, svm_result['accuracy']*100, mlp_result['accuracy']*100, qnn_result['accuracy']*100]
    f1_scores = [baseline['f1'], svm_result['f1'], mlp_result['f1'], qnn_result['f1']]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986']

    bars1 = ax1.bar(models, acc_scores, color=colors, width=0.55)
    ax1.set_ylabel('Test Accuracy (%)')
    ax1.set_title(f'Accuracy (N_test={len(X_test)})')
    ax1.set_ylim(0, 100)
    for bar in bars1:
        yv = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2, yv + 1.5, f"{yv:.1f}%", ha='center', fontweight='bold', fontsize=9)

    bars2 = ax2.bar(models, f1_scores, color=colors, width=0.55)
    ax2.set_ylabel('F1 Score (positive class)')
    ax2.set_title('F1 Score (more informative under class imbalance)')
    ax2.set_ylim(0, 1)
    for bar in bars2:
        yv = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2, yv + 0.02, f"{yv:.2f}", ha='center', fontweight='bold', fontsize=9)

    plt.suptitle('SMN2 Splice-Site Prediction: Classical vs Quantum (4 qubits)', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/classical_vs_quantum_4qubit.png", dpi=130)
    print("\n Saved figures/classical_vs_quantum_4qubit.png")

    with open("results/benchmark_results.json", "w", encoding="utf-8") as f:
        json.dump({"baseline": baseline, "svm": svm_result, "mlp": mlp_result,
                    "qnn": qnn_result, "qnn_test_loss": qnn_loss, "n_test": len(X_test)},
                   f, ensure_ascii=False, indent=2)
    print(" Saved results/benchmark_results.json")
