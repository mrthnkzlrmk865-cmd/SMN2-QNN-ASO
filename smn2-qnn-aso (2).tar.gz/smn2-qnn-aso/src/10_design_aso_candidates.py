import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from Bio import SeqIO

from qiskit_aer import AerSimulator

import sys
sys.path.insert(0, "src")
from importlib import import_module
qnn_module = import_module("02_train_qnn")
build_circuit = qnn_module.build_circuit
prob_one = qnn_module.prob_one

N_QUBITS = 4
SHOTS = 400
GENOMIC_FASTA = "data/smn2_genomic.fasta"
ISS_N1_FILE = "results/iss_n1_region.txt"

NN_DELTA_G = {
    'AA': -0.93, 'UU': -0.93, 'AU': -1.10, 'UA': -1.33,
    'CU': -2.08, 'AG': -2.08, 'CA': -2.11, 'UG': -2.11,
    'GU': -2.24, 'AC': -2.24, 'GA': -2.35, 'UC': -2.35,
    'CG': -2.36, 'GG': -3.26, 'CC': -3.26, 'GC': -3.42,
}
INIT_PENALTY = 4.09


def base_to_radian(base):
    mapping = {'A': 0.0, 'T': np.pi / 2, 'U': np.pi / 2, 'G': np.pi, 'C': (3 * np.pi) / 2}
    return mapping.get(base.upper(), 0.0)


def complement(rna_seq):
    comp = {'A': 'U', 'U': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(comp.get(b, b) for b in rna_seq.upper())


def reverse_complement(rna_seq):
    return complement(rna_seq)[::-1]


def duplex_delta_g(rna_seq):
    seq = ''.join(c for c in rna_seq.upper().replace('T', 'U') if c in 'AUGC')
    if len(seq) < 2:
        return 0.0
    total = INIT_PENALTY
    for i in range(len(seq) - 1):
        total += NN_DELTA_G.get(seq[i:i+2], -1.5)
    return round(total, 2)


def gc_content(rna_seq):
    seq = ''.join(c for c in rna_seq.upper() if c in 'AUGC')
    return sum(1 for c in seq if c in 'GC') / len(seq) if seq else 0.0


def qnn_scan_window(rna_seq, opt_params, shots=SHOTS):
    seq = ''.join(c for c in rna_seq.upper().replace('T', 'U') if c in 'AUGC')
    sim = AerSimulator()
    probs = []
    for i in range(len(seq) - N_QUBITS + 1):
        window = seq[i:i + N_QUBITS]
        angles = [base_to_radian(b) for b in window]
        p1 = prob_one(sim, opt_params, angles, shots=shots)
        probs.append(p1)
    return (float(np.mean(probs)) if probs else 0.0), probs


def off_target_scan(rna_seq, target_genomic, max_mismatch=2):
    rc = reverse_complement(rna_seq)
    target = str(target_genomic).upper().replace('T', 'U')
    n = len(rc)
    if n == 0 or len(target) < n:
        return 0.0, 0
    matches = 0
    for i in range(len(target) - n + 1):
        window = target[i:i+n]
        mismatches = sum(1 for a, b in zip(window, rc) if a != b)
        if mismatches <= max_mismatch:
            matches += 1
    risk = min(matches / 5.0, 1.0)
    return risk, matches


def generate_aso_candidates(iss_n1_seq, length=18, count=5):
    record = next(SeqIO.parse(GENOMIC_FASTA, "fasta"))
    genomic = str(record.seq).upper()

    position = genomic.find(iss_n1_seq)
    if position == -1:
        raise ValueError("ISS-N1 sequence not found in genomic data.")

    candidates = {}
    start_points = np.linspace(max(0, position - 5), position + 10, count, dtype=int)
    for i, start in enumerate(start_points):
        target_dna = genomic[start: start + length]
        if len(target_dna) < length:
            continue
        target_rna = target_dna.replace('T', 'U')
        aso_rna = reverse_complement(target_rna)
        candidates[f"ASO-{i+1} (pos {start})"] = aso_rna

    control_position = 2000
    control_dna = genomic[control_position:control_position + length].replace('T', 'U')
    candidates["ASO-Control (outside ISS-N1)"] = reverse_complement(control_dna)

    return candidates


if __name__ == "__main__":
    with open("results/qnn_trained_parameters.json", "r", encoding="utf-8") as f:
        train_info = json.load(f)
    opt_params = np.array(train_info["opt_params"])

    with open(ISS_N1_FILE) as f:
        iss_n1 = f.read().strip()
    print(f" ISS-N1 target region: {iss_n1}")

    record = next(SeqIO.parse(GENOMIC_FASTA, "fasta"))
    target_genomic = str(record.seq).upper()

    aso_candidates = generate_aso_candidates(iss_n1, length=18, count=5)
    print(f" Generated {len(aso_candidates)} ASO candidates")

    results = []
    for name, seq in aso_candidates.items():
        print(f"\n -> {name}: {seq}")

        avg_p1, _ = qnn_scan_window(seq, opt_params)
        delta_g = duplex_delta_g(seq)
        stability_score = float(np.clip((-delta_g) / 40.0, 0, 1))
        off_target_risk, match_count = off_target_scan(seq, target_genomic)
        gc = gc_content(seq)

        print(f"    QNN avg P(1)={avg_p1:.3f} | dG={delta_g} kcal/mol | "
              f"off-target matches={match_count} | GC%={gc*100:.1f}")

        results.append({
            "ASO": name, "Sequence": seq,
            "Quantum Binding Affinity": round(avg_p1, 3),
            "Off-Target Risk (lower=better)": round(off_target_risk, 3),
            "Exon 7 Inclusion Potential (%)": round(avg_p1 * 100, 1),
            "Thermodynamic Stability Score": round(stability_score, 3),
            "Raw dG (kcal/mol)": delta_g,
            "GC Content": round(gc, 2)
        })

    df_scores = pd.DataFrame(results).set_index("ASO")
    print("\n\n=== ALL CANDIDATE SCORES ===")
    print(df_scores[["Quantum Binding Affinity", "Off-Target Risk (lower=better)",
                     "Exon 7 Inclusion Potential (%)", "Thermodynamic Stability Score"]])

    heatmap_cols = ["Quantum Binding Affinity", "Off-Target Risk (lower=better)",
                    "Exon 7 Inclusion Potential (%)", "Thermodynamic Stability Score"]
    plt.figure(figsize=(10, 6))
    sns.heatmap(df_scores[heatmap_cols].astype(float), annot=True, fmt=".2f",
                cmap="YlGnBu", cbar=True, linewidths=1)
    plt.title("SMN2 ISS-N1-Targeted ASO Candidates - QNN-Based Dynamic Evaluation",
              fontsize=11, fontweight='bold')
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.savefig("figures/aso_candidate_heatmap.png", dpi=130)
    print("\n Saved figures/aso_candidate_heatmap.png")

    df_scores.to_csv("results/aso_candidate_scores.csv")
    print(" Saved results/aso_candidate_scores.csv")
