import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

FEATURES_CSV = "results/quantum_features.csv"
TEST_SIZE = 0.20
SEED = 42
PSEUDOCOUNT = 1.0
BASES = ['A', 'U', 'G', 'C']


def to_rna(window):
    return window.upper().replace('T', 'U')


def learn_markov1(windows, length):
    start_counts = np.full(len(BASES), PSEUDOCOUNT)
    transition_counts = np.full((length - 1, len(BASES), len(BASES)), PSEUDOCOUNT)

    for window in windows:
        window = to_rna(window)
        if len(window) != length:
            continue
        if window[0] in BASES:
            start_counts[BASES.index(window[0])] += 1
        for pos in range(1, length):
            prev, curr = window[pos-1], window[pos]
            if prev in BASES and curr in BASES:
                transition_counts[pos-1, BASES.index(prev), BASES.index(curr)] += 1

    start_probs = start_counts / start_counts.sum()
    transition_probs = transition_counts / transition_counts.sum(axis=2, keepdims=True)
    return start_probs, transition_probs


def markov1_score(window, start_probs, transition_probs):
    window = to_rna(window)
    if window[0] not in BASES:
        return 0.0
    score = np.log(start_probs[BASES.index(window[0])])
    for pos in range(1, len(window)):
        prev, curr = window[pos-1], window[pos]
        if prev in BASES and curr in BASES and pos-1 < transition_probs.shape[0]:
            score += np.log(transition_probs[pos-1, BASES.index(prev), BASES.index(curr)])
    return score


def find_best_threshold(scores, labels):
    candidates = np.unique(scores)
    best_threshold, best_f1 = 0.0, -1
    for threshold in candidates:
        f1 = f1_score(labels, (scores >= threshold).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_threshold = f1, threshold
    return best_threshold, best_f1


def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }


if __name__ == "__main__":
    df = pd.read_csv(FEATURES_CSV)
    y = df['label'].values
    window_length = len(to_rna(df['window'].iloc[0]))

    idx_all = np.arange(len(df))
    idx_train, idx_test = train_test_split(idx_all, test_size=TEST_SIZE, random_state=SEED, stratify=y)
    df_train = df.iloc[idx_train].reset_index(drop=True)
    df_test = df.iloc[idx_test].reset_index(drop=True)
    print(f" Train: {len(df_train)} (positive={int(df_train['label'].sum())}) | "
          f"Test: {len(df_test)} (positive={int(df_test['label'].sum())})")

    total_test_preds = np.zeros(len(df_test), dtype=int)

    for site_type in ['donor', 'acceptor']:
        print(f"\n--- Learning {site_type.upper()} 1st-order Markov model ---")
        train_type = df_train[df_train['site_type'] == site_type]
        test_type_mask = (df_test['site_type'] == site_type).values

        positives = train_type[train_type['label'] == 1]['window'].tolist()
        negatives = train_type[train_type['label'] == 0]['window'].tolist()
        print(f" Train {site_type}: {len(positives)} positive, {len(negatives)} negative")

        start_pos, trans_pos = learn_markov1(positives, window_length)
        start_neg, trans_neg = learn_markov1(negatives, window_length)

        train_scores = np.array([
            markov1_score(w, start_pos, trans_pos) - markov1_score(w, start_neg, trans_neg)
            for w in train_type['window']
        ])
        threshold, train_f1 = find_best_threshold(train_scores, train_type['label'].values)
        print(f" Threshold on train: {threshold:.3f} (train F1={train_f1:.3f})")

        test_windows = df_test.loc[test_type_mask, 'window']
        test_scores = np.array([
            markov1_score(w, start_pos, trans_pos) - markov1_score(w, start_neg, trans_neg)
            for w in test_windows
        ])
        test_preds = (test_scores >= threshold).astype(int)
        total_test_preds[test_type_mask] = test_preds

        type_metric = compute_metrics(df_test.loc[test_type_mask, 'label'].values, test_preds)
        print(f" Test ({site_type}) -> Accuracy={type_metric['accuracy']*100:.1f}% F1={type_metric['f1']:.3f}")

    y_test_all = df_test['label'].values
    maxent_metric = compute_metrics(y_test_all, total_test_preds)
    print(f"\n=== MaxEnt-like (1st-order Markov/WAM) Overall Test Result ===")
    print(f" Accuracy: {maxent_metric['accuracy']*100:.2f}% | Precision: {maxent_metric['precision']:.3f} | "
          f"Recall: {maxent_metric['recall']:.3f} | F1: {maxent_metric['f1']:.3f}")

    with open("results/benchmark_results.json", "r", encoding="utf-8") as f:
        previous = json.load(f)
    with open("results/pwm_comparison_results.json", "r", encoding="utf-8") as f:
        pwm_results = json.load(f)

    final_comparison = {
        "Baseline": previous["baseline"],
        "SVM (4 features)": previous["svm"],
        "MLP (4 features)": previous["mlp"],
        "QNN (4 qubits)": previous["qnn"],
        "PWM (0th-order, independent positions)": pwm_results["PWM (domain-specific)"],
        "MaxEnt-like (1st-order Markov/WAM)": maxent_metric,
    }

    print("\n=== FINAL COMPARISON: ALL MODELS ===")
    for name, m in final_comparison.items():
        print(f" {name:42s}: Acc={m['accuracy']*100:5.1f}%  Prec={m['precision']:.3f}  "
              f"Recall={m['recall']:.3f}  F1={m['f1']:.3f}")

    with open("results/final_comparison.json", "w", encoding="utf-8") as f:
        json.dump(final_comparison, f, ensure_ascii=False, indent=2)

    df_table = pd.DataFrame([
        {"Model": name, "Accuracy(%)": round(m['accuracy']*100, 1), "Precision": round(m['precision'], 3),
         "Recall": round(m['recall'], 3), "F1": round(m['f1'], 3)}
        for name, m in final_comparison.items()
    ])
    df_table.to_csv("results/final_comparison.csv", index=False)
    print("\n Saved results/final_comparison.csv")

    names = list(final_comparison.keys())
    f1_values = [final_comparison[k]['f1'] for k in names]
    acc_values = [final_comparison[k]['accuracy']*100 for k in names]
    recall_values = [final_comparison[k]['recall'] for k in names]
    colors = ['#999999', '#4a90e2', '#50e3c2', '#b8e986', '#e67e22', '#c0392b']

    fig, axes = plt.subplots(1, 3, figsize=(18, 5.5))
    for ax, values, title, ylabel in zip(
        axes, [f1_values, acc_values, recall_values],
        ['F1 Score', 'Accuracy (%)', 'Recall'], ['F1', 'Accuracy (%)', 'Recall']
    ):
        bars = ax.bar(range(len(names)), values, color=colors)
        ax.set_xticks(range(len(names)))
        ax.set_xticklabels(names, rotation=30, ha='right', fontsize=8)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid(alpha=0.3, axis='y')
        for bar, v in zip(bars, values):
            label = f"{v:.2f}" if v < 10 else f"{v:.1f}%"
            ax.text(bar.get_x()+bar.get_width()/2, v + max(values)*0.02, label,
                    ha='center', fontsize=7.5, fontweight='bold')

    plt.suptitle('SMN2 + BRCA1 + TP53 + CFTR + HBB: Final Model Comparison\n'
                 '(Baseline / SVM / MLP / QNN / PWM / MaxEnt-like Markov)', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/final_comparison.png", dpi=130)
    print(" Saved figures/final_comparison.png")
