import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from Bio import SeqIO
from scipy.stats import mannwhitneyu

import sys
sys.path.insert(0, "src")
from importlib import import_module
qnn_module = import_module("02_train_qnn")
aso_module = import_module("10_design_aso_candidates")

prob_one = qnn_module.prob_one
base_to_radian = aso_module.base_to_radian
reverse_complement = aso_module.reverse_complement
N_QUBITS = aso_module.N_QUBITS

from qiskit_aer import AerSimulator

GENOMIC_FASTA = "data/smn2_genomic.fasta"
INTRON7_START = 32052
INTRON7_END = 32496
ISS_N1_CORE_START = 9   # offset within intron 7 (0-indexed), matches earlier ISS-N1 extraction
ISS_N1_CORE_LEN = 15
TARGET_REGION_FLANK = 15  # extra flanking nt around the core for alignment search

W_QNN = 0.2
W_ON_TARGET = 0.6
W_OFF_TARGET = 0.2


def qnn_scan_window(rna_seq, opt_params, shots=400):
    seq = ''.join(c for c in rna_seq.upper().replace('T', 'U') if c in 'AUGC')
    sim = AerSimulator()
    probs = []
    for i in range(len(seq) - N_QUBITS + 1):
        window = seq[i:i + N_QUBITS]
        angles = [base_to_radian(b) for b in window]
        p1 = prob_one(sim, opt_params, angles, shots=shots)
        probs.append(p1)
    return float(np.mean(probs)) if probs else 0.0


def on_target_complementarity(aso_rna, target_region_rna):
    rc = reverse_complement(aso_rna)
    n = len(rc)
    target = target_region_rna.upper().replace('T', 'U')
    if len(target) < n:
        return 0.0, -1
    best_fraction, best_offset = 0.0, -1
    for i in range(len(target) - n + 1):
        window = target[i:i+n]
        matches = sum(1 for a, b in zip(window, rc) if a == b)
        fraction = matches / n
        if fraction > best_fraction:
            best_fraction, best_offset = fraction, i
    return best_fraction, best_offset


def off_target_term(aso_rna, genomic_seq, exclude_start, exclude_end, min_identity=0.85):
    rc = reverse_complement(aso_rna)
    n = len(rc)
    target = genomic_seq.upper().replace('T', 'U')
    if n == 0 or len(target) < n:
        return 1.0, 0
    hits = 0
    for i in range(len(target) - n + 1):
        if i < exclude_end and i + n > exclude_start:
            continue
        window = target[i:i+n]
        identity = sum(1 for a, b in zip(window, rc) if a == b) / n
        if identity >= min_identity:
            hits += 1
    risk = min(hits / 3.0, 1.0)
    return risk, hits


if __name__ == "__main__":
    with open("results/qnn_trained_parameters.json", "r", encoding="utf-8") as f:
        train_info = json.load(f)
    opt_params = np.array(train_info["opt_params"])

    record = next(SeqIO.parse(GENOMIC_FASTA, "fasta"))
    genomic = str(record.seq).upper()
    intron7 = genomic[INTRON7_START:INTRON7_END]

    core_start = ISS_N1_CORE_START - TARGET_REGION_FLANK
    core_end = ISS_N1_CORE_START + ISS_N1_CORE_LEN + TARGET_REGION_FLANK
    target_region_dna = intron7[max(0, core_start):core_end]
    target_region_rna = target_region_dna.replace('T', 'U')
    print(f" True ISS-N1 target region used for on-target scoring (with flanks): {target_region_dna}")

    old_df = pd.read_csv("results/retrospective_aso_validation.csv")

    results = []
    for _, row in old_df.iterrows():
        name, dna_seq, category = row["ASO"], row["Sequence"], row["Category"]
        rna_seq = dna_seq.replace('T', 'U')

        qnn_p1 = qnn_scan_window(rna_seq, opt_params)
        complementarity, offset = on_target_complementarity(rna_seq, target_region_rna)

        exclude_start_genomic = INTRON7_START + max(0, core_start)
        exclude_end_genomic = exclude_start_genomic + len(target_region_dna)
        off_risk, off_hits = off_target_term(rna_seq, genomic, exclude_start_genomic, exclude_end_genomic)

        new_score = W_QNN * qnn_p1 + W_ON_TARGET * complementarity + W_OFF_TARGET * (1 - off_risk)

        print(f"\n{name} [{category}]")
        print(f"  QNN_P1={qnn_p1:.3f} | on_target_complementarity={complementarity:.3f} "
              f"(best local alignment, offset={offset}) | off_target_risk={off_risk:.3f} (hits={off_hits}) "
              f"| new_score={new_score:.3f}")

        results.append({
            "ASO": name, "Sequence": dna_seq, "Category": category,
            "QNN_P1": round(qnn_p1, 3),
            "On_Target_Complementarity": round(complementarity, 3),
            "Off_Target_Risk_v2": round(off_risk, 3),
            "New_Score": round(new_score, 3),
            "Old_Score": row["Combined_Score"], "Old_Rank": row["Rank"]
        })

    df = pd.DataFrame(results).sort_values("New_Score", ascending=False).reset_index(drop=True)
    df["New_Rank"] = df.index + 1
    print("\n=== NEW SCORING: RETROSPECTIVE RANKING ===")
    print(df[["New_Rank", "ASO", "Category", "QNN_P1", "On_Target_Complementarity",
              "Off_Target_Risk_v2", "New_Score", "Old_Rank"]].to_string(index=False))

    active = df[df["Category"] == "active"]
    control = df[df["Category"] == "control"]
    print(f"\n Active mean new score: {active['New_Score'].mean():.4f} | "
          f"Control mean new score: {control['New_Score'].mean():.4f}")
    print(f" Active mean new rank: {active['New_Rank'].mean():.2f} | "
          f"Control mean new rank: {control['New_Rank'].mean():.2f}")

    if len(active) >= 2 and len(control) >= 2:
        stat, p_value = mannwhitneyu(active["New_Score"], control["New_Score"], alternative='greater')
        print(f" Mann-Whitney U (active > control): U={stat:.1f}, p={p_value:.3f}")
    else:
        p_value = None

    df.to_csv("results/aso_scoring_v2_results.csv", index=False)
    with open("results/aso_scoring_v2_summary.json", "w", encoding="utf-8") as f:
        json.dump({
            "active_mean_score": float(active['New_Score'].mean()),
            "control_mean_score": float(control['New_Score'].mean()),
            "active_mean_rank": float(active['New_Rank'].mean()),
            "control_mean_rank": float(control['New_Rank'].mean()),
            "mann_whitney_p": float(p_value) if p_value is not None else None,
            "weights": {"QNN": W_QNN, "OnTargetComplementarity": W_ON_TARGET, "OffTarget": W_OFF_TARGET},
        }, f, ensure_ascii=False, indent=2)
    print("\n Saved results/aso_scoring_v2_results.csv and results/aso_scoring_v2_summary.json")

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    colors_old = ['#2ecc71' if c == 'active' else '#e74c3c' for c in old_df.sort_values('Rank')['Category']]
    axes[0].barh(old_df.sort_values('Rank', ascending=False)['ASO'],
                 old_df.sort_values('Rank', ascending=False)['Combined_Score'],
                 color=[('#2ecc71' if c == 'active' else '#e74c3c')
                        for c in old_df.sort_values('Rank', ascending=False)['Category']])
    axes[0].set_title('OLD Scoring System')
    axes[0].set_xlabel('Old Combined Score')

    df_sorted = df.sort_values('New_Score')
    axes[1].barh(df_sorted['ASO'], df_sorted['New_Score'],
                 color=[('#2ecc71' if c == 'active' else '#e74c3c') for c in df_sorted['Category']])
    axes[1].set_title('NEW Scoring System (on-target complementarity based)')
    axes[1].set_xlabel('New Score')

    plt.suptitle('ASO Scoring: Old vs New (green = published active, red = control)', fontweight='bold')
    plt.tight_layout()
    plt.savefig("figures/aso_scoring_old_vs_new.png", dpi=130)
    print(" Saved figures/aso_scoring_old_vs_new.png")
