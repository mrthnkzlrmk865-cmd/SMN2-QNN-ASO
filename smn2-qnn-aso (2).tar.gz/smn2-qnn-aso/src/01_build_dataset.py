import numpy as np
import pandas as pd
from Bio import SeqIO

WINDOW_HALF = 10
MIN_EXON_LENGTH = 15
KMER_LENGTH = 20
MAX_NEGATIVES_PER_GENE = 80

GENE_LIST = [
    {"name": "SMN2",  "genomic": "data/smn2_genomic.fasta",  "mrna": "data/smn2_mrna.fasta"},
    {"name": "BRCA1", "genomic": "data/brca1_genomic.fasta", "mrna": "data/brca1_mrna.fasta"},
    {"name": "TP53",  "genomic": "data/tp53_genomic.fasta",  "mrna": "data/tp53_mrna.fasta"},
    {"name": "CFTR",  "genomic": "data/cftr_genomic.fasta",  "mrna": "data/cftr_mrna.fasta"},
    {"name": "HBB",   "genomic": "data/hbb_genomic.fasta",   "mrna": "data/hbb_mrna.fasta"},
]


def build_kmer_index(seq, k=KMER_LENGTH):
    index = {}
    for i in range(len(seq) - k + 1):
        index.setdefault(seq[i:i+k], []).append(i)
    return index


def find_exons_fast(genomic, mrna, k=KMER_LENGTH, min_exon=MIN_EXON_LENGTH):
    idx = build_kmer_index(genomic, k)
    blocks = []
    m_pos = 0
    n_m = len(mrna)
    while m_pos < n_m - k:
        kmer = mrna[m_pos:m_pos+k]
        candidates = idx.get(kmer, [])
        if not candidates:
            m_pos += 1
            continue
        if blocks:
            last_g_end = blocks[-1][1]
            candidates = sorted(candidates, key=lambda g: abs(g - last_g_end))
        g_pos = candidates[0]

        g_end, m_end = g_pos, m_pos
        while g_end < len(genomic) and m_end < len(mrna) and genomic[g_end] == mrna[m_end]:
            g_end += 1; m_end += 1
        g_start, m_start = g_pos, m_pos
        while g_start > 0 and m_start > 0 and genomic[g_start-1] == mrna[m_start-1]:
            g_start -= 1; m_start -= 1

        if g_end - g_start >= min_exon:
            blocks.append((g_start, g_end, m_start, m_end))
        m_pos = max(m_end, m_pos + 1)
    return blocks


def refine_boundary_to_canonical_gt_ag(genomic_seq, exon_end, next_exon_start, max_shift=8):
    donor_pos, donor_found = None, False
    for shift in range(0, max_shift + 1):
        for direction in ([shift, -shift] if shift > 0 else [0]):
            d = exon_end + direction
            if 0 <= d <= len(genomic_seq) - 2 and genomic_seq[d:d+2] == 'GT':
                donor_pos, donor_found = d, True
                break
        if donor_found:
            break

    acceptor_pos, acceptor_found = None, False
    for shift in range(0, max_shift + 1):
        for direction in ([shift, -shift] if shift > 0 else [0]):
            a = next_exon_start + direction
            if 2 <= a <= len(genomic_seq) and genomic_seq[a-2:a] == 'AG':
                acceptor_pos, acceptor_found = a, True
                break
        if acceptor_found:
            break

    if donor_found and acceptor_found and acceptor_pos > donor_pos:
        return donor_pos, acceptor_pos, True
    return exon_end, next_exon_start, False


def extract_window(seq, center_pos, center_length, half=WINDOW_HALF):
    left = seq[center_pos - half: center_pos]
    center = seq[center_pos: center_pos + center_length]
    right = seq[center_pos + center_length: center_pos + center_length + half]
    window = left + center + right
    if len(window) != 2 * half + center_length:
        return None
    return window


def base_to_radian(base):
    mapping = {'A': 0.0, 'T': np.pi / 2, 'U': np.pi / 2, 'G': np.pi, 'C': (3 * np.pi) / 2}
    return mapping.get(base.upper(), 0.0)


def process_gene(name, genomic_file, mrna_file, seed=42):
    print(f"\n{'='*55}\n GENE: {name}\n{'='*55}")
    genomic_rec = next(SeqIO.parse(genomic_file, "fasta"))
    mrna_rec = next(SeqIO.parse(mrna_file, "fasta"))
    genomic_seq = str(genomic_rec.seq).upper()
    mrna_seq = str(mrna_rec.seq).upper()
    print(f" Genomic: {genomic_rec.description[:80]} ({len(genomic_seq)} bp)")
    print(f" mRNA   : {mrna_rec.description[:80]} ({len(mrna_seq)} bp)")

    blocks = find_exons_fast(genomic_seq, mrna_seq)
    print(f" Exon blocks found: {len(blocks)}")

    boundaries = []
    for i in range(len(blocks) - 1):
        exon_end = blocks[i][1]
        next_exon_start = blocks[i+1][0]
        if next_exon_start <= exon_end:
            continue
        d, a, confirmed = refine_boundary_to_canonical_gt_ag(genomic_seq, exon_end, next_exon_start)
        boundaries.append({"donor_pos": d, "acceptor_pos": a, "confirmed": confirmed})

    confirmed_count = sum(1 for b in boundaries if b["confirmed"])
    print(f" Total introns: {len(boundaries)} | Confirmed canonical GT...AG: {confirmed_count}")

    records = []
    confirmed_positions = set()
    for b in boundaries:
        if not b["confirmed"]:
            continue
        confirmed_positions.add(b["donor_pos"])
        confirmed_positions.add(b["acceptor_pos"] - 2)
        d_window = extract_window(genomic_seq, b["donor_pos"], 2)
        if d_window:
            records.append({"gene": name, "position": b["donor_pos"], "site_type": "donor",
                             "window": d_window, "label": 1, "source": "real_alignment"})
        a_window = extract_window(genomic_seq, b["acceptor_pos"] - 2, 2)
        if a_window:
            records.append({"gene": name, "position": b["acceptor_pos"] - 2, "site_type": "acceptor",
                             "window": a_window, "label": 1, "source": "real_alignment"})

    rng = np.random.default_rng(seed)
    candidates = []
    n = len(genomic_seq)
    for i in range(WINDOW_HALF, n - WINDOW_HALF - 2):
        pair = genomic_seq[i:i+2]
        if pair not in ('GT', 'AG'):
            continue
        if any(abs(i - p) <= 3 for p in confirmed_positions):
            continue
        candidates.append(i)

    selected = rng.choice(candidates, size=min(MAX_NEGATIVES_PER_GENE, len(candidates)), replace=False) if candidates else []
    for i in selected:
        window = extract_window(genomic_seq, int(i), 2)
        if window:
            site_type = 'donor' if genomic_seq[i:i+2] == 'GT' else 'acceptor'
            records.append({"gene": name, "position": int(i), "site_type": site_type,
                             "window": window, "label": 0, "source": "confirmed_negative"})

    n_pos = sum(1 for r in records if r["label"] == 1)
    n_neg = sum(1 for r in records if r["label"] == 0)
    print(f" -> {name}: {n_pos} positive, {n_neg} negative generated.")
    return records


if __name__ == "__main__":
    all_records = []
    gene_summary = []
    for gene_info in GENE_LIST:
        try:
            records = process_gene(gene_info["name"], gene_info["genomic"], gene_info["mrna"])
            all_records.extend(records)
            n_pos = sum(1 for r in records if r["label"] == 1)
            n_neg = sum(1 for r in records if r["label"] == 0)
            gene_summary.append({"gene": gene_info["name"], "positive": n_pos, "negative": n_neg})
        except Exception as e:
            print(f" WARNING: failed to process {gene_info['name']}, skipping -> {e}")

    df = pd.DataFrame(all_records)
    print(f"\n{'='*55}\n TOTAL (all genes combined): {len(df)} rows")
    print(f" Class distribution:\n{df['label'].value_counts()}")
    print(pd.DataFrame(gene_summary).to_string(index=False))

    quantum_rows = [[base_to_radian(b) for b in window] for window in df['window']]
    columns = [f'angle_{i}' for i in range(len(df['window'].iloc[0]))]
    df_features = pd.DataFrame(quantum_rows, columns=columns)
    df_final = pd.concat([df.reset_index(drop=True), df_features], axis=1)

    df_final.to_csv("results/quantum_features.csv", index=False)
    print(f"\n Saved results/quantum_features.csv, shape={df_final.shape}")
